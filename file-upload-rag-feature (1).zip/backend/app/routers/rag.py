"""
RAG router — file-upload-rag feature (FEATURE_MODULE_MAP #16/#17).

Endpoints
---------
POST   /api/rag/ingest               { document_id }
POST   /api/rag/ask                  { document_id, question, history? }
DELETE /api/rag/documents/{document_id}

How it works
------------
* Frontend uploads the raw file to Supabase Storage and inserts an
  `uploaded_documents` row (status='processing'), then calls /ingest.
* /ingest downloads the file with the service-role key, extracts text
  (pypdf for PDFs, utf-8 for txt/md/csv), splits it into overlapping
  chunks, embeds each chunk (Gemini text-embedding-001, 768 dims) and
  stores them in `document_chunks` (pgvector). Status becomes 'ready'.
* /ask embeds the question, retrieves the top-k chunks with the
  `match_document_chunks` SQL function, and answers via Groq
  (fallback: Gemini) with source citations.
* Images skip RAG entirely — the raw image + question are sent to a
  vision model (Gemini) so users can ask "what is in this diagram?".

Environment (.env in backend/)
------------------------------
SUPABASE_URL                  e.g. https://xyz.supabase.co
SUPABASE_SERVICE_ROLE_KEY     service role key (never ship to frontend)
GROQ_API_KEY                  free tier at console.groq.com  (chat)
GEMINI_API_KEY                free tier at aistudio.google.com (embeddings + vision + chat fallback)

Python requirements addition:  pypdf==4.3.1
"""

from __future__ import annotations

import base64
import io
import os
from typing import Any, Optional

import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from supabase import Client, createClient

router = APIRouter(prefix="/api/rag", tags=["rag"])

# ── configuration ───────────────────────────────────────────────────────────
SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")

GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.1-8b-instant")
GEMINI_TEXT_MODEL = os.environ.get("GEMINI_TEXT_MODEL", "gemini-1.5-flash")
GEMINI_EMBED_MODEL = os.environ.get("GEMINI_EMBED_MODEL", "text-embedding-001")
GEMINI_VISION_MODEL = os.environ.get("GEMINI_VISION_MODEL", "gemini-1.5-flash")

CHUNK_SIZE = 1200        # characters per chunk
CHUNK_OVERLAP = 200      # characters shared between neighbouring chunks
TOP_K = 5                # chunks retrieved per question

_http = httpx.AsyncClient(timeout=90)
_db: Optional[Client] = None


def db() -> Client:
    """Supabase client with the service-role key (backend-only)."""
    global _db
    if _db is None:
        if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
            raise HTTPException(
                500, "SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured"
            )
        _db = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    return _db


# ── request models ──────────────────────────────────────────────────────────
class IngestRequest(BaseModel):
    document_id: str


class ChatMessage(BaseModel):
    role: str  # "user" | "assistant"
    content: str


class AskRequest(BaseModel):
    document_id: str
    question: str = Field(min_length=1, max_length=2000)
    history: list[ChatMessage] = Field(default_factory=list)


# ── helpers ─────────────────────────────────────────────────────────────────
def split_chunks(text: str) -> list[str]:
    """Sliding window over characters — simple, robust, no dependencies."""
    text = text.strip()
    if not text:
        return []
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = min(len(text), start + CHUNK_SIZE)
        chunks.append(text[start:end].strip())
        if end >= len(text):
            break
        start = end - CHUNK_OVERLAP
    return [c for c in chunks if c]


def extract_pdf_text(raw: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:  # pragma: no cover
        raise HTTPException(
            500, "pypdf is not installed — add `pypdf==4.3.1` to requirements.txt"
        ) from exc
    reader = PdfReader(io.BytesIO(raw))
    return "\n\n".join((page.extract_text() or "") for page in reader.pages)


async def embed_texts(texts: list[str]) -> list[list[float]]:
    """Gemini batch embeddings (768 dims)."""
    if not GEMINI_API_KEY:
        raise HTTPException(500, "GEMINI_API_KEY not configured (needed for embeddings)")
    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_EMBED_MODEL}:batchEmbedContents"
    )
    payload = {
        "requests": [
            {"model": f"models/{GEMINI_EMBED_MODEL}", "content": {"parts": [{"text": t}]}}
            for t in texts
        ]
    }
    r = await _http.post(url, params={"key": GEMINI_API_KEY}, json=payload)
    if r.status_code != 200:
        raise HTTPException(502, f"Embedding failed: {r.text[:300]}")
    return [item["values"] for item in r.json()["embeddings"]]


async def chat_completion(system: str, messages: list[dict]) -> str:
    """Groq first, Gemini fallback (free-tier LLMs with fallback)."""
    if GROQ_API_KEY:
        r = await _http.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
            json={
                "model": GROQ_MODEL,
                "messages": [{"role": "system", "content": system}, *messages],
                "temperature": 0.2,
            },
        )
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]

    if GEMINI_API_KEY:
        contents = [
            {
                "role": "model" if m["role"] == "assistant" else "user",
                "parts": [{"text": m["content"]}],
            }
            for m in messages
        ]
        r = await _http.post(
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{GEMINI_TEXT_MODEL}:generateContent",
            params={"key": GEMINI_API_KEY},
            json={
                "systemInstruction": {"parts": [{"text": system}]},
                "contents": contents,
                "generationConfig": {"temperature": 0.2},
            },
        )
        if r.status_code == 200:
            return r.json()["candidates"][0]["content"]["parts"][0]["text"]

    raise HTTPException(502, "No LLM available — set GROQ_API_KEY or GEMINI_API_KEY")


async def vision_ask(image_bytes: bytes, mime: str, question: str) -> str:
    """Ask a question about an image using Gemini vision."""
    if not GEMINI_API_KEY:
        raise HTTPException(500, "GEMINI_API_KEY not configured (needed for image Q&A)")
    b64 = base64.b64encode(image_bytes).decode()
    r = await _http.post(
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_VISION_MODEL}:generateContent",
        params={"key": GEMINI_API_KEY},
        json={
            "contents": [
                {
                    "role": "user",
                    "parts": [
                        {"text": question},
                        {"inlineData": {"mimeType": mime or "image/png", "data": b64}},
                    ],
                }
            ]
        },
    )
    if r.status_code != 200:
        raise HTTPException(502, f"Vision model failed: {r.text[:300]}")
    return r.json()["candidates"][0]["content"]["parts"][0]["text"]


def get_document(document_id: str) -> dict:
    res = db().table("uploaded_documents").select("*").eq("id", document_id).execute()
    rows = res.data or []
    if not rows:
        raise HTTPException(404, "Document not found")
    return rows[0]


# ── endpoints ───────────────────────────────────────────────────────────────
@router.post("/ingest")
async def ingest(req: IngestRequest) -> dict:
    """Extract → chunk → embed → store. Called once after upload."""
    supabase = db()
    doc = get_document(req.document_id)

    def set_status(status: str, **extra: Any) -> None:
        supabase.table("uploaded_documents").update({"status": status, **extra}).eq(
            "id", req.document_id
        ).execute()

    try:
        raw = supabase.storage.from_("documents").download(doc["storage_path"])
    except Exception as exc:
        set_status("error", error=f"download failed: {exc}")
        raise HTTPException(500, f"Could not download file from storage: {exc}") from exc

    kind = doc.get("kind") or "doc"

    # Images are answered via the vision model at ask-time — no RAG needed.
    if kind == "image":
        set_status("ready", chunk_count=0)
        return {"status": "ready", "chunks": 0, "mode": "vision"}

    text = extract_pdf_text(raw) if kind == "pdf" else raw.decode("utf-8", errors="ignore")

    chunks = split_chunks(text)
    if not chunks:
        set_status("error", error="no extractable text (scanned PDF? try an image instead)")
        raise HTTPException(422, "No extractable text found in this document")

    embeddings = await embed_texts(chunks)

    # replace any previous chunks for this document
    supabase.table("document_chunks").delete().eq("document_id", req.document_id).execute()
    supabase.table("document_chunks").insert(
        [
            {
                "document_id": req.document_id,
                "user_id": doc["user_id"],
                "chunk_index": i,
                "content": content,
                "embedding": embedding,
            }
            for i, (content, embedding) in enumerate(zip(chunks, embeddings))
        ]
    ).execute()

    set_status("ready", chunk_count=len(chunks))
    return {"status": "ready", "chunks": len(chunks), "mode": "rag"}


@router.post("/ask")
async def ask(req: AskRequest) -> dict:
    """Answer a question about one document (RAG for text, vision for images)."""
    supabase = db()
    doc = get_document(req.document_id)

    if doc.get("status") != "ready":
        raise HTTPException(409, "Document is still processing — try again in a moment")

    # ── images → vision model ───────────────────────────────────────────────
    if (doc.get("kind") or "") == "image":
        raw = supabase.storage.from_("documents").download(doc["storage_path"])
        answer = await vision_ask(raw, doc.get("mime_type") or "image/png", req.question)
        return {"answer": answer, "sources": [], "mode": "vision"}

    # ── PDFs / docs → RAG ───────────────────────────────────────────────────
    [query_embedding] = await embed_texts([req.question])
    matches = supabase.rpc(
        "match_document_chunks",
        {
            "p_document_id": req.document_id,
            "p_query_embedding": query_embedding,
            "p_match_count": TOP_K,
        },
    ).execute()
    chunks = matches.data or []
    if not chunks:
        raise HTTPException(422, "No indexed content found for this document")

    context = "\n\n".join(
        f"[Source {c['chunk_index']}] {c['content']}" for c in chunks
    )
    system = (
        "You are a study assistant. Answer ONLY from the provided document "
        "sources. Cite sources inline like [Source 3]. If the answer is not in "
        "the sources, say you could not find it in the document.\n\n"
        f"Document: {doc['name']}\n\nSources:\n{context}"
    )
    messages = [
        {"role": m.role, "content": m.content} for m in req.history[-4:]
    ] + [{"role": "user", "content": req.question}]

    answer = await chat_completion(system, messages)
    return {
        "answer": answer,
        "sources": [
            {"chunk_index": c["chunk_index"], "quote": c["content"][:220]}
            for c in chunks
        ],
        "mode": "rag",
    }


@router.delete("/documents/{document_id}")
async def delete_document(document_id: str) -> dict:
    """Remove the file, its chunks and its row."""
    supabase = db()
    doc = get_document(document_id)
    try:
        supabase.storage.from_("documents").remove([doc["storage_path"]])
    except Exception:
        pass  # best-effort
    supabase.table("document_chunks").delete().eq("document_id", document_id).execute()
    supabase.table("uploaded_documents").delete().eq("id", document_id).execute()
    return {"deleted": document_id}
