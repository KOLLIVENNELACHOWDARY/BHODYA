import { supabase } from "../../supabaseClient";
import { backend } from "../../backendClient";

// ─────────────────────────────────────────────────────────────────────────────
// File-upload + RAG feature (Supabase Storage + FastAPI routers/rag.py).
//
//   uploadDocument()  → Storage + `uploaded_documents` row + kick off /ingest
//   askDocument()     → POST /api/rag/ask (RAG or vision, per file kind)
//   deleteDocument()  → DELETE /api/rag/documents/{id}
//
// Tables: uploaded_documents, document_chunks (0004_file_upload_rag.sql)
// Bucket: documents (private)
// ─────────────────────────────────────────────────────────────────────────────

const BUCKET = "documents";
const ACCEPTED = [".pdf", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".txt", ".md", ".csv"];

export function kindFromName(name = "") {
  const lower = name.toLowerCase();
  if (lower.endsWith(".pdf")) return "pdf";
  if (/\.(png|jpe?g|webp|gif)$/.test(lower)) return "image";
  return "doc";
}

export function isAccepted(file) {
  const lower = file.name.toLowerCase();
  return ACCEPTED.some((ext) => lower.endsWith(ext));
}

async function authHeaders() {
  const {
    data: { session },
  } = await supabase.auth.getSession();
  return session?.access_token
    ? { Authorization: `Bearer ${session.access_token}` }
    : {};
}

// ── documents ───────────────────────────────────────────────────────────────

export async function listDocuments() {
  const { data, error } = await supabase
    .from("uploaded_documents")
    .select("id, name, kind, status, error, size_bytes, chunk_count, created_at")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

/**
 * Upload one file, register it, and kick off ingestion (fire-and-forget).
 * Returns the document row immediately (status: 'processing'); poll
 * listDocuments() until status is 'ready' or 'error'.
 */
export async function uploadDocument(file) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Please sign in to upload files.");
  if (!isAccepted(file)) {
    throw new Error(`Unsupported file type. Use: ${ACCEPTED.join(", ")}`);
  }

  const id = crypto.randomUUID();
  const path = `${user.id}/${id}/${file.name}`;

  const { error: upErr } = await supabase.storage
    .from(BUCKET)
    .upload(path, file, { upsert: false });
  if (upErr) throw upErr;

  const { data: doc, error: insErr } = await supabase
    .from("uploaded_documents")
    .insert({
      id,
      user_id: user.id,
      name: file.name,
      storage_path: path,
      mime_type: file.type || null,
      size_bytes: file.size,
      kind: kindFromName(file.name),
      status: "processing",
    })
    .select()
    .single();
  if (insErr) throw insErr;

  // Fire-and-forget: ingest on the backend; the UI polls status meanwhile.
  backend
    .post("/api/rag/ingest", { document_id: id }, { headers: await authHeaders() })
    .catch(() => {});

  return doc;
}

export async function deleteDocument(documentId) {
  const { error } = await backend.delete(`/api/rag/documents/${documentId}`, {
    headers: await authHeaders(),
  });
  if (error) throw error;
}

// ── Q&A ─────────────────────────────────────────────────────────────────────

/**
 * Ask a question about one document.
 * `history`: [{ role: "user"|"assistant", content: "..." }, ...]
 * Returns { answer, sources: [{ chunk_index, quote }], mode: "rag"|"vision" }.
 */
export async function askDocument(documentId, question, history = []) {
  const { data, error } = await backend.post(
    "/api/rag/ask",
    { document_id: documentId, question, history },
    { headers: await authHeaders() }
  );
  if (error) throw error;
  return data;
}
