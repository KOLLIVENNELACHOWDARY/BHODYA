import { useCallback, useEffect, useRef, useState } from "react";
import { uploadDocument, listDocuments, deleteDocument, isAccepted } from "./api";
import UploadDropzone from "./components/UploadDropzone";
import FileList from "./components/FileList";
import ChatPanel from "./components/ChatPanel";

/**
 * `/files` — Upload PDFs / images / docs, then ask questions about them.
 *
 * Left:  upload zone + document library (status chips: processing / ready / error)
 * Right: per-document chat — RAG with source citations for text, vision for images.
 */
export default function FileUploadRagPage() {
  const [docs, setDocs] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const pollRef = useRef(null);

  const load = useCallback(async () => {
    try {
      const rows = await listDocuments();
      setDocs(rows);
      return rows;
    } catch {
      return [];
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // poll every 3 s while any document is still processing
  useEffect(() => {
    const anyProcessing = docs.some((d) => d.status === "processing");
    clearInterval(pollRef.current);
    if (anyProcessing) {
      pollRef.current = setInterval(load, 3000);
    }
    return () => clearInterval(pollRef.current);
  }, [docs, load]);

  async function handleFiles(fileList) {
    setError(null);
    setUploading(true);
    try {
      for (const file of Array.from(fileList)) {
        if (!isAccepted(file)) {
          setError(`Skipped "${file.name}" — unsupported file type.`);
          continue;
        }
        await uploadDocument(file);
      }
      await load();
    } catch (err) {
      setError(err?.message ?? "Upload failed.");
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this file and its indexed content?")) return;
    try {
      await deleteDocument(id);
      if (selectedId === id) setSelectedId(null);
      await load();
    } catch (err) {
      setError(err?.message ?? "Delete failed.");
    }
  }

  const selected = docs.find((d) => d.id === selectedId) ?? null;

  return (
    <div className="min-h-screen bg-slate-50 px-6 py-8">
      <div className="mx-auto max-w-6xl">
        {/* header */}
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            Files &amp; ask-anything
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Upload PDFs, images or notes — then ask questions and get answers with
            source citations.
          </p>
        </div>

        {error ? (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        {/* two-column layout */}
        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[1.15fr_1fr]">
          {/* LEFT: upload + library */}
          <div>
            <UploadDropzone onFiles={handleFiles} uploading={uploading} />
            <div className="mt-4">
              <h2 className="mb-2 text-sm font-semibold text-slate-700">
                Your documents ({docs.length})
              </h2>
              <FileList
                docs={docs}
                selectedId={selectedId}
                onSelect={setSelectedId}
                onDelete={handleDelete}
              />
            </div>
          </div>

          {/* RIGHT: chat */}
          <div>
            {selected ? (
              <ChatPanel doc={selected} />
            ) : (
              <div className="flex h-full min-h-[560px] flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center">
                <div className="text-4xl">💬</div>
                <p className="mt-3 text-sm font-medium text-slate-700">
                  Select a file to start asking
                </p>
                <p className="mt-1 max-w-xs text-xs text-slate-400">
                  Click a <b>ready</b> document on the left — a chat about that
                  specific file opens here. PDFs answer with citations; images use
                  vision AI.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
