# File Upload + RAG — upload PDFs/images/docs and ask questions

Implements **FEATURE_MODULE_MAP #16 (Upload PDFs/docs/images + query — RAG)** and
**#17 (curation of study material)**. Route: `/files`.

This is the first feature that needs the **FastAPI backend** ("AI service") —
exactly as ARCHITECTURE.md describes: the frontend handles upload/auth/storage
directly, and calls FastAPI only for AI reasoning (`routers/rag.py`).

## What it does

| Part | How |
|---|---|
| 📤 Upload | Drag & drop PDFs, images (png/jpg/webp/gif), text (txt/md/csv). Files go to the private `documents` Storage bucket |
| 🗂️ Library | File list with status chips: `processing…` → `ready` / `error`, size, chunk count, delete |
| 💬 Ask (PDFs/docs) | **Full RAG**: text is chunked + embedded (Gemini, 768-dim pgvector) → questions retrieve top-5 chunks → LLM answers **with [Source n] citations** (Groq, fallback Gemini) |
| 💬 Ask (images) | **Vision AI** (Gemini): “what is in this diagram?” gets an answer from the image itself |
| 🧠 Chat | Per-document conversation panel with suggested questions and message history |

## Files

| File | Purpose |
|---|---|
| `index.jsx` | `/files` page: upload + library (left) + chat (right) |
| `api.js` | Storage upload, document rows, FastAPI calls |
| `components/UploadDropzone.jsx` | Drag & drop / browse picker |
| `components/FileList.jsx` | Document library with status chips |
| `components/ChatPanel.jsx` | Per-document Q&A with source citations |
| `backend/app/routers/rag.py` | **FastAPI router** — ingest / ask / delete |
| `supabase/migrations/0004_file_upload_rag.sql` | `uploaded_documents` + `document_chunks` (pgvector) + bucket + RLS |

## Setup

**1. Migration** — run `supabase/migrations/0004_file_upload_rag.sql`
(safe if `0001_init.sql` already created the tables — all `if not exists`).
It enables `pgvector`, creates the `match_document_chunks()` search function,
and the private `documents` storage bucket.

**2. Backend** — copy `backend/app/routers/rag.py` into your FastAPI app, then:

```python
# backend/app/main.py
from app.routers import rag
app.include_router(rag.router)
```

Add to `backend/requirements.txt`:

```
pypdf==4.3.1
```

Set env vars in `backend/.env`:

```
SUPABASE_URL=https://YOUR-PROJECT.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...
GROQ_API_KEY=...        # console.groq.com  (chat)
GEMINI_API_KEY=...      # aistudio.google.com (embeddings + vision + fallback chat)
```

**3. Frontend** — one route in `App.jsx`:

```jsx
import FileUploadRagPage from "./features/file-upload-rag";
// ...
<Route path="/files" element={<FileUploadRagPage />} />
```

(`VITE_BACKEND_URL` must point at the FastAPI server — `backendClient.js` already uses it.)

## API contract (for API_CONTRACTS.md)

**Endpoint:** `POST /api/rag/ingest`

```json
{ "document_id": "uuid" }
```

_Response:_ `{ "status": "ready", "chunks": 14, "mode": "rag" | "vision" }`

**Endpoint:** `POST /api/rag/ask`

```json
{
  "document_id": "uuid",
  "question": "What is photosynthesis?",
  "history": [{ "role": "user", "content": "..." }]
}
```

_Response:_

```json
{
  "answer": "Photosynthesis is … [Source 3]",
  "sources": [{ "chunk_index": 3, "quote": "…" }],
  "mode": "rag"
}
```

**Endpoint:** `DELETE /api/rag/documents/{document_id}` → `{ "deleted": "uuid" }`

**Notes:** send the Supabase access token as `Authorization: Bearer <token>`
(optional in dev). Ingest runs once per file after upload; `/ask` returns
409 while status is `processing`. Images use `mode: "vision"` (no chunks).

## How the RAG pipeline works

```
upload → Storage bucket "documents"
      → uploaded_documents row (processing)
      → POST /api/rag/ingest
          ├─ pypdf text extraction (PDF) / utf-8 (txt,md,csv)
          ├─ split into ~1200-char chunks (200 overlap)
          ├─ Gemini embeddings (768 dims) → document_chunks
          └─ status = ready
ask    → POST /api/rag/ask
          ├─ embed question
          ├─ match_document_chunks() → top-5 pgvector hits
          ├─ Groq (fallback Gemini) answers with [Source n] citations
          └─ sources returned for the UI
image  → raw image + question → Gemini vision (no embedding step)
```

## Assumptions / notes

- Gemini `text-embedding-001` = **768 dims** (matches `vector(768)` in the
  migration and `EMBEDDING_DIMS` docs in `rag.py`). If you switch embedding
  models, change the column type + the SQL function accordingly.
- Free-tier LLMs per ARCHITECTURE.md: **Groq first, Gemini fallback**.
- Scanned PDFs with no text layer return `status: "error"` — upload them as
  images instead and use vision Q&A.
- The chat keeps the last 4 messages as context (`history`).
- Imports assume `supabaseClient.js` + `backendClient.js` live at
  `frontend/src/`.
