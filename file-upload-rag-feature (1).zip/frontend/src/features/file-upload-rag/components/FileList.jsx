const KIND_ICON = {
  pdf: "📕",
  image: "🖼️",
  doc: "📄",
};

const STATUS_CHIP = {
  processing: "bg-amber-100 text-amber-700",
  ready: "bg-green-100 text-green-700",
  error: "bg-red-100 text-red-700",
};

function formatSize(bytes = 0) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

/**
 * The document library list.
 * `docs`      — rows from uploaded_documents
 * `selectedId` + `onSelect(id)` — click a row to open its chat
 * `onDelete(id)` — trash button
 */
export default function FileList({ docs, selectedId, onSelect, onDelete }) {
  if (docs.length === 0) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center">
        <div className="text-3xl">🗂️</div>
        <p className="mt-2 text-sm text-slate-500">
          No files yet — upload a PDF or image to start asking questions.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white">
      <ul className="divide-y divide-slate-100">
        {docs.map((doc) => (
          <li
            key={doc.id}
            onClick={() => doc.status === "ready" && onSelect(doc.id)}
            className={`flex items-center gap-3 px-4 py-3 transition ${
              doc.id === selectedId
                ? "bg-indigo-50"
                : doc.status === "ready"
                  ? "cursor-pointer hover:bg-slate-50"
                  : "opacity-70"
            }`}
          >
            <span className="text-xl">{KIND_ICON[doc.kind] ?? "📄"}</span>

            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-slate-900">{doc.name}</p>
              <p className="text-xs text-slate-400">
                {formatSize(doc.size_bytes)}
                {doc.kind === "pdf" || doc.kind === "doc" ? (
                  <> · {doc.chunk_count ?? 0} chunks</>
                ) : null}
                {doc.status === "error" && doc.error ? (
                  <span className="text-red-500"> · {doc.error}</span>
                ) : null}
              </p>
            </div>

            <span
              className={`rounded-full px-2 py-0.5 text-xs font-semibold ${STATUS_CHIP[doc.status]}`}
            >
              {doc.status === "processing" ? "processing…" : doc.status}
            </span>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(doc.id);
              }}
              title="Delete file"
              className="rounded-lg px-2 py-1 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
            >
              🗑
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
