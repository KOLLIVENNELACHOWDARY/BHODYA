import { useRef, useState } from "react";

const ACCEPT_TEXT = "PDF · PNG · JPG · WEBP · TXT · MD · CSV";

/**
 * Drag & drop upload zone.
 * `onFiles(files: FileList)` is called for every picked/dropped batch.
 */
export default function UploadDropzone({ onFiles, uploading }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);

  function handleDrop(e) {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files?.length) onFiles(e.dataTransfer.files);
  }

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
      onClick={() => inputRef.current?.click()}
      className={`cursor-pointer rounded-2xl border-2 border-dashed px-6 py-8 text-center transition ${
        dragging
          ? "border-indigo-500 bg-indigo-50"
          : "border-slate-300 bg-white hover:border-indigo-300"
      }`}
    >
      <input
        ref={inputRef}
        type="file"
        multiple
        accept=".pdf,.png,.jpg,.jpeg,.webp,.gif,.txt,.md,.csv"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) onFiles(e.target.files);
          e.target.value = "";
        }}
      />
      <div className="text-3xl">{uploading ? "⏳" : "📤"}</div>
      <p className="mt-2 text-sm font-medium text-slate-700">
        {uploading
          ? "Uploading… keep this page open"
          : "Drag & drop files here, or click to browse"}
      </p>
      <p className="mt-1 text-xs text-slate-400">{ACCEPT_TEXT}</p>
    </div>
  );
}
