import { useEffect, useRef, useState } from "react";
import { askDocument } from "../api";

/**
 * Per-document chat: ask questions about ONE uploaded file.
 * PDFs/docs → RAG answers with [Source n] citations.
 * Images → vision model answers.
 */
export default function ChatPanel({ doc, onSessionChange }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState(null);
  const bottomRef = useRef(null);

  // reset the conversation when a different file is selected
  useEffect(() => {
    setMessages([]);
    setError(null);
    onSessionChange?.([]);
  }, [doc?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, thinking]);

  const suggested = [
    "Summarize this document",
    "What are the key points?",
    "Explain the main topic simply",
    doc?.kind === "image" ? "What is in this image?" : "List the important definitions",
  ];

  async function send(question) {
    const q = (question ?? input).trim();
    if (!q || thinking || !doc) return;

    const history = messages.map((m) => ({ role: m.role, content: m.content }));
    const next = [...messages, { role: "user", content: q }];
    setMessages(next);
    setInput("");
    setThinking(true);
    setError(null);

    try {
      const res = await askDocument(doc.id, q, history);
      const updated = [
        ...next,
        { role: "assistant", content: res.answer, sources: res.sources ?? [], mode: res.mode },
      ];
      setMessages(updated);
      onSessionChange?.(updated);
    } catch (err) {
      setError(err?.response?.data?.detail ?? err?.message ?? "Failed to get an answer.");
    } finally {
      setThinking(false);
    }
  }

  return (
    <div className="flex h-full min-h-[560px] flex-col rounded-2xl border border-slate-200 bg-white">
      {/* header */}
      <div className="border-b border-slate-100 px-4 py-3">
        <p className="text-sm font-semibold text-slate-900">💬 Ask about this file</p>
        <p className="truncate text-xs text-slate-400">{doc.name}</p>
      </div>

      {/* messages */}
      <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
        {messages.length === 0 ? (
          <div>
            <p className="text-sm text-slate-500">
              Ask anything about <b>{doc.name}</b>. Answers come straight from the
              document{doc.kind === "image" ? " (image understanding)" : " with source citations"}
              .
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {suggested.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="rounded-full border border-slate-300 px-3 py-1.5 text-xs text-slate-600 transition hover:border-indigo-400 hover:text-indigo-600"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm ${
                  m.role === "user"
                    ? "bg-indigo-600 text-white"
                    : "bg-slate-100 text-slate-800"
                }`}
              >
                <p className="whitespace-pre-wrap">{m.content}</p>

                {m.sources?.length ? (
                  <div className="mt-2 space-y-1 border-t border-slate-200 pt-2">
                    {m.sources.map((s, j) => (
                      <div
                        key={j}
                        className="rounded-lg bg-white/70 px-2 py-1 text-[11px] text-slate-500"
                      >
                        <b className="text-indigo-600">[Source {s.chunk_index}]</b>{" "}
                        {s.quote}
                        {s.quote?.length >= 220 ? "…" : ""}
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            </div>
          ))
        )}

        {thinking ? (
          <div className="flex justify-start">
            <div className="rounded-2xl bg-slate-100 px-3.5 py-2.5 text-sm text-slate-500">
              Thinking<span className="animate-pulse">…</span>
            </div>
          </div>
        ) : null}

        {error ? (
          <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
            {error}
          </div>
        ) : null}

        <div ref={bottomRef} />
      </div>

      {/* input */}
      <div className="border-t border-slate-100 p-3">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send();
          }}
          className="flex gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Ask about ${doc.name.slice(0, 24)}…`}
            className="flex-1 rounded-xl border border-slate-300 px-3 py-2.5 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
          />
          <button
            type="submit"
            disabled={thinking || !input.trim()}
            className="rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:opacity-50"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}
