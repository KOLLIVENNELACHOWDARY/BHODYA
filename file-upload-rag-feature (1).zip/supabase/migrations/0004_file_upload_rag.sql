-- File-upload + RAG feature (FEATURE_MODULE_MAP #16/#17).
-- Adds: uploaded_documents + document_chunks (pgvector) + storage bucket.
--
-- NOTE: ARCHITECTURE.md says these tables may already exist in 0001_init.sql —
-- every statement is `if not exists`, so running this is safe either way.
--
-- Flow: frontend uploads the raw file to Storage + inserts an
-- uploaded_documents row → POST /api/rag/ingest extracts/chunks/embeds text
-- into document_chunks → POST /api/rag/ask retrieves top-k chunks and asks
-- the LLM (images go to a vision model instead of RAG).

create extension if not exists vector;

-- ── documents ───────────────────────────────────────────────────────────────
create table if not exists public.uploaded_documents (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users (id) on delete cascade,
  name         text not null,
  storage_path text not null,
  mime_type    text,
  size_bytes   bigint default 0,
  kind         text not null default 'doc'
               check (kind in ('pdf', 'image', 'doc')),
  status       text not null default 'processing'
               check (status in ('processing', 'ready', 'error')),
  error        text,
  chunk_count  integer default 0,
  created_at   timestamptz not null default now()
);

create index if not exists uploaded_documents_user_idx
  on public.uploaded_documents (user_id, created_at desc);

-- ── chunks with embeddings ──────────────────────────────────────────────────
-- Gemini text-embedding-001 → 768 dimensions.
create table if not exists public.document_chunks (
  id          uuid primary key default gen_random_uuid(),
  document_id uuid not null references public.uploaded_documents (id) on delete cascade,
  user_id     uuid not null references auth.users (id) on delete cascade,
  chunk_index integer not null,
  content     text not null,
  embedding   vector(768),
  created_at  timestamptz not null default now()
);

create index if not exists document_chunks_doc_idx
  on public.document_chunks (document_id, chunk_index);

create index if not exists document_chunks_embedding_idx
  on public.document_chunks
  using ivfflat (embedding vector_cosine_ops) with (lists = 100);

-- ── similarity search (called by the backend via service key) ───────────────
create or replace function public.match_document_chunks(
  p_document_id uuid,
  p_query_embedding vector(768),
  p_match_count integer default 5
)
returns table (id uuid, chunk_index integer, content text, similarity float)
language sql
stable
as $$
  select
    c.id,
    c.chunk_index,
    c.content,
    1 - (c.embedding <=> p_query_embedding) as similarity
  from public.document_chunks c
  where c.document_id = p_document_id
    and c.embedding is not null
  order by c.embedding <=> p_query_embedding
  limit p_match_count;
$$;

-- ── RLS ─────────────────────────────────────────────────────────────────────
-- Users manage their own documents. Chunk writes/reads happen through the
-- FastAPI backend (service role key, bypasses RLS).
alter table public.uploaded_documents enable row level security;
alter table public.document_chunks     enable row level security;

create policy "docs_select_own"
  on public.uploaded_documents for select
  using (auth.uid() = user_id);

create policy "docs_insert_own"
  on public.uploaded_documents for insert
  with check (auth.uid() = user_id);

create policy "docs_update_own"
  on public.uploaded_documents for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "docs_delete_own"
  on public.uploaded_documents for delete
  using (auth.uid() = user_id);

-- ── private storage bucket for raw files ────────────────────────────────────
insert into storage.buckets (id, name, public)
values ('documents', 'documents', false)
on conflict (id) do nothing;

-- Files live under documents/<user_id>/<document_id>/<filename>:
-- users may only touch objects inside their own folder.
create policy "storage_documents_insert_own"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_documents_select_own"
  on storage.objects for select
  to authenticated
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "storage_documents_delete_own"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'documents'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
