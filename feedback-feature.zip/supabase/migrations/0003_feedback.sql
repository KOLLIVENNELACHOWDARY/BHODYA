-- Feedback feature: user submissions, recorded on the admin side.
-- Adds: public.feedback table + is_admin flag on profiles.
--
-- User page  (/feedback)        → inserts rows here
-- Admin page (/admin/feedback)  → reads/updates rows (spreadsheet view)
-- Google Sheets: export CSV from the admin page, or keep it in-app.

-- ── admin flag on the existing profiles table ───────────────────────────────
alter table public.profiles
  add column if not exists is_admin boolean not null default false;

-- ── feedback table ──────────────────────────────────────────────────────────
create table if not exists public.feedback (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users (id) on delete cascade,
  name       text,
  email      text,
  rating     integer not null check (rating between 1 and 5),
  category   text not null default 'Suggestion'
             check (category in ('Suggestion', 'Bug', 'Praise', 'Other')),
  message    text not null check (char_length(message) between 1 and 4000),
  status     text not null default 'new'
             check (status in ('new', 'reviewed', 'resolved')),
  admin_note text,
  created_at timestamptz not null default now()
);

create index if not exists feedback_created_idx on public.feedback (created_at desc);
create index if not exists feedback_status_idx  on public.feedback (status);

alter table public.feedback enable row level security;

-- ── helper: "is the current user an admin?" ─────────────────────────────────
-- security definer avoids recursive RLS lookups on profiles.
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select coalesce(
    (select is_admin from public.profiles where id = auth.uid()),
    false
  );
$$;

grant execute on function public.is_admin() to authenticated;

-- ── policies ────────────────────────────────────────────────────────────────
-- Any signed-in user may submit feedback (their own row only).
create policy "feedback_insert_own"
  on public.feedback for insert
  to authenticated
  with check (auth.uid() = user_id);

-- Only admins can read / triage / delete the collected feedback.
create policy "feedback_admin_select"
  on public.feedback for select
  using (public.is_admin());

create policy "feedback_admin_update"
  on public.feedback for update
  using (public.is_admin())
  with check (public.is_admin());

create policy "feedback_admin_delete"
  on public.feedback for delete
  using (public.is_admin());

-- ── grant yourself admin (run once) ─────────────────────────────────────────
-- update public.profiles set is_admin = true where id = auth.uid();
