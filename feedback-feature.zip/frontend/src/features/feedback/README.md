# Feedback — user form + admin spreadsheet

A **separate** feature (nothing from usage-overview in here). Users submit
feedback from `/feedback`; every submission is recorded as a row on the
admin-only spreadsheet at `/admin/feedback` — laid out like Google Sheets,
with sortable columns, search, status triage and CSV export that opens
directly in Google Sheets.

Maps to **FEATURE_MODULE_MAP #23 (Suggestions & Reviews)** territory.

## What it does

| Side | Route | What it does |
|---|---|---|
| 👤 User page | `/feedback` | ⭐ 1–5 star rating + category (Suggestion / Bug / Praise / Other) + message → inserts one row into `feedback` |
| 🗄️ Admin page | `/admin/feedback` | Google-Sheets-style grid of **all** rows: row numbers, sortable columns, search, status filter, inline status change (`new → reviewed → resolved`), inline admin notes, **Export CSV → Google Sheets** |

## Files

| File | Purpose |
|---|---|
| `index.jsx` | User feedback form (default export) + re-exports `AdminFeedbackSheet` |
| `AdminFeedbackSheet.jsx` | The admin spreadsheet page (admin-gated) |
| `api.js` | Supabase calls: `submitFeedback`, `fetchFeedback`, `updateFeedback`, `isAdmin` |
| `utils.js` | CSV builder + download + date formatting |
| `components/StarRating.jsx` | 1–5 stars (editable on the form, read-only in the sheet) |
| `supabase/migrations/0003_feedback.sql` | `feedback` table + `is_admin` flag on `profiles` + RLS |

## Setup

**1. Apply the migration** (`supabase/migrations/0003_feedback.sql`):

- creates `feedback` (rating, category, message, status, admin_note…)
- adds `is_admin boolean default false` to `profiles`
- RLS: signed-in users can **insert their own** row; only admins can
  **select / update / delete**

**2. Make yourself admin** (run once in the Supabase SQL editor):

```sql
update public.profiles set is_admin = true where id = auth.uid();
```

**3. Wire up `App.jsx`** (the only file outside this folder you touch):

```jsx
import FeedbackPage, { AdminFeedbackSheet } from "./features/feedback";

// inside your router:
<Routes>
  {/* ...your existing routes... */}
  <Route path="/feedback" element={<FeedbackPage />} />
  <Route path="/admin/feedback" element={<AdminFeedbackSheet />} />
</Routes>
```

Add nav links: “Feedback” for everyone, “Admin” (to `/admin/feedback`) for
admins. No FastAPI needed — this feature is Supabase-only.

## Google Sheets

The admin sheet works like Google Sheets in-app; to get the data **into** a
real Google Sheet: click **⬇ Export CSV → Google Sheets**, then open the CSV
with Google Sheets (or File → Import). The CSV columns are exactly the sheet
columns: Received, Name, Email, Rating, Category, Feedback, Status, Admin note.

## Assumptions (adjust if your schema differs)

- `profiles` table exists and gets an `is_admin` column (added by the
  migration). If you prefer email-based admin checks, replace `isAdmin()`
  in `api.js`.
- Feedback requires a signed-in user (`authenticated` insert policy). To
  allow anonymous feedback, add an `anon` insert policy in the migration.
- Rows are capped at the latest 500 in the sheet (fine for feedback volume).
- Imports assume `supabaseClient.js` lives at `frontend/src/supabaseClient.js`.
