import { useState } from "react";
import { submitFeedback, CATEGORIES } from "./api";
import StarRating from "./components/StarRating";

// Admin-only spreadsheet view — mount at /admin/feedback.
export { default as AdminFeedbackSheet } from "./AdminFeedbackSheet";

const MIN_MESSAGE = 5;

/**
 * `/feedback` — user-facing feedback form:
 *   ⭐ 1–5 rating · category (Suggestion / Bug / Praise / Other) · message.
 * Saves one row to Supabase `feedback` — recorded on the admin sheet.
 */
export default function FeedbackPage() {
  const [rating, setRating] = useState(0);
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);

  const canSubmit = rating >= 1 && message.trim().length >= MIN_MESSAGE && !submitting;

  async function handleSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    setError(null);
    try {
      await submitFeedback({ rating, category, message });
      setDone(true);
      setRating(0);
      setMessage("");
      setCategory(CATEGORIES[0]);
    } catch (err) {
      setError(err?.message ?? "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-start justify-center bg-slate-50 px-6 py-12">
      <div className="w-full max-w-xl">
        {done ? (
          /* ── success state ─────────────────────────────── */
          <div className="rounded-2xl bg-white p-10 text-center shadow-sm ring-1 ring-slate-200">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-3xl">
              ✅
            </div>
            <h1 className="mt-5 text-xl font-semibold text-slate-900">
              Thanks for your feedback!
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              It has been recorded and our team will review it soon.
            </p>
            <button
              onClick={() => setDone(false)}
              className="mt-6 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-indigo-700"
            >
              Send another feedback
            </button>
          </div>
        ) : (
          /* ── form ───────────────────────────────────────── */
          <form
            onSubmit={handleSubmit}
            className="rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200"
          >
            <h1 className="text-2xl font-semibold text-slate-900">
              Share your feedback
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              How are we doing? Ideas, bugs, praise — we read everything.
            </p>

            {/* rating */}
            <div className="mt-7">
              <label className="text-sm font-medium text-slate-700">
                Your rating
              </label>
              <div className="mt-2">
                <StarRating value={rating} onChange={setRating} />
              </div>
            </div>

            {/* category */}
            <div className="mt-6">
              <label className="text-sm font-medium text-slate-700">
                Category
              </label>
              <div className="mt-2 flex flex-wrap gap-2">
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(c)}
                    className={`rounded-full border px-4 py-1.5 text-sm transition ${
                      category === c
                        ? "border-indigo-600 bg-indigo-600 text-white"
                        : "border-slate-300 bg-white text-slate-600 hover:border-indigo-300"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* message */}
            <div className="mt-6">
              <label
                htmlFor="feedback-message"
                className="text-sm font-medium text-slate-700"
              >
                Your feedback
              </label>
              <textarea
                id="feedback-message"
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell us what you liked, or what we should fix…"
                className="mt-2 w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
              />
              <p className="mt-1 text-right text-xs text-slate-400">
                {message.trim().length} / 4000
              </p>
            </div>

            {/* error */}
            {error ? (
              <div className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
                {error}
              </div>
            ) : null}

            {/* submit */}
            <button
              type="submit"
              disabled={!canSubmit}
              className="mt-4 w-full rounded-xl bg-indigo-600 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {submitting ? "Sending…" : "Submit feedback"}
            </button>
            <p className="mt-3 text-center text-xs text-slate-400">
              {rating >= 1 && message.trim().length >= MIN_MESSAGE
                ? "Ready to send 🚀"
                : "Add a rating and a few words to enable submit"}
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
