import { supabase } from "../../supabaseClient";

// ─────────────────────────────────────────────────────────────────────────────
// Feedback feature (Supabase-only — no FastAPI needed).
//
//   public.feedback  → see supabase/migrations/0003_feedback.sql
//   public.profiles.is_admin → admin flag that gates the admin sheet
//
// If your profiles / column names differ, adjust the small constants below.
// ─────────────────────────────────────────────────────────────────────────────

const FEEDBACK_COLUMNS =
  "id, user_id, name, email, rating, category, message, status, admin_note, created_at";

export const CATEGORIES = ["Suggestion", "Bug", "Praise", "Other"];
export const STATUSES = ["new", "reviewed", "resolved"];

async function currentUser() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user ?? null;
}

/** True when the signed-in user has profiles.is_admin = true. */
export async function isAdmin() {
  const user = await currentUser();
  if (!user) return false;
  const { data, error } = await supabase
    .from("profiles")
    .select("is_admin")
    .eq("id", user.id)
    .single();
  if (error) return false;
  return Boolean(data?.is_admin);
}

// ── user page: submit ───────────────────────────────────────────────────────

/** Insert one feedback row. Throws on failure. */
export async function submitFeedback({ rating, category, message }) {
  const user = await currentUser();
  if (!user) throw new Error("Please sign in to send feedback.");

  const { error } = await supabase.from("feedback").insert({
    user_id: user.id,
    name:
      user.user_metadata?.full_name ??
      user.user_metadata?.name ??
      user.email?.split("@")[0] ??
      "Anonymous",
    email: user.email ?? "",
    rating,
    category,
    message: message.trim(),
  });
  if (error) throw error;
}

// ── admin page: read & triage ───────────────────────────────────────────────

/**
 * Fetch feedback rows for the admin sheet (newest first).
 * `status`: "all" | "new" | "reviewed" | "resolved"
 * `search`: free text matched against name / email / category / message.
 */
export async function fetchFeedback({ status = "all", search = "" } = {}) {
  let query = supabase
    .from("feedback")
    .select(FEEDBACK_COLUMNS)
    .order("created_at", { ascending: false })
    .limit(500);

  if (status !== "all") query = query.eq("status", status);

  const q = search.trim();
  if (q) {
    const safe = q.replace(/[%_,()]/g, " "); // keep the .or() filter well-formed
    query = query.or(
      `name.ilike.%${safe}%,email.ilike.%${safe}%,category.ilike.%${safe}%,message.ilike.%${safe}%`
    );
  }

  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

/** Update status and/or admin note of one row. */
export async function updateFeedback(id, { status, adminNote } = {}) {
  const patch = {};
  if (status !== undefined) patch.status = status;
  if (adminNote !== undefined) patch.admin_note = adminNote;
  if (Object.keys(patch).length === 0) return;

  const { error } = await supabase.from("feedback").update(patch).eq("id", id);
  if (error) throw error;
}
