import { useCallback, useEffect, useMemo, useState } from "react";
import { fetchFeedback, updateFeedback, isAdmin, STATUSES } from "./api";
import { feedbackToCsv, downloadCsv, formatDateTime } from "./utils";
import StarRating from "./components/StarRating";

const STATUS_STYLES = {
  new: "bg-amber-100 text-amber-700",
  reviewed: "bg-blue-100 text-blue-700",
  resolved: "bg-green-100 text-green-700",
};

const COLUMNS = [
  { key: "created_at", label: "Received" },
  { key: "name", label: "Name" },
  { key: "email", label: "Email" },
  { key: "rating", label: "Rating" },
  { key: "category", label: "Category" },
  { key: "message", label: "Feedback" },
  { key: "status", label: "Status" },
];

/**
 * `/admin/feedback` — Google-Sheets-style admin spreadsheet.
 * Every feedback submission appears as a row: sortable columns, search,
 * status filter, inline status change, CSV export (opens in Google Sheets).
 */
export default function AdminFeedbackSheet() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortKey, setSortKey] = useState("created_at");
  const [sortAsc, setSortAsc] = useState(false);
  const [admin, setAdmin] = useState(null); // null = checking

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setRows(await fetchFeedback({ status: statusFilter, search }));
    } catch (err) {
      setError(err?.message ?? "Failed to load feedback.");
    } finally {
      setLoading(false);
    }
  }, [statusFilter, search]);

  useEffect(() => {
    isAdmin().then(setAdmin);
  }, []);

  useEffect(() => {
    if (admin) load();
  }, [admin, load]);

  // sorted copy for rendering
  const sorted = useMemo(() => {
    const list = [...rows];
    list.sort((a, b) => {
      const va = a[sortKey] ?? "";
      const vb = b[sortKey] ?? "";
      const cmp =
        typeof va === "number" && typeof vb === "number"
          ? va - vb
          : String(va).localeCompare(String(vb));
      return sortAsc ? cmp : -cmp;
    });
    return list;
  }, [rows, sortKey, sortAsc]);

  const counts = useMemo(
    () => ({
      total: rows.length,
      new: rows.filter((r) => r.status === "new").length,
      reviewed: rows.filter((r) => r.status === "reviewed").length,
      resolved: rows.filter((r) => r.status === "resolved").length,
    }),
    [rows]
  );

  function toggleSort(key) {
    if (key === sortKey) setSortAsc(!sortAsc);
    else {
      setSortKey(key);
      setSortAsc(true);
    }
  }

  async function changeStatus(id, status) {
    setRows((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status } : r))
    );
    try {
      await updateFeedback(id, { status });
    } catch (err) {
      setError(err?.message ?? "Failed to update status.");
      load();
    }
  }

  // ── admin gate ────────────────────────────────────────────────────────────
  if (admin === null) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 text-sm text-slate-500">
        Checking admin access…
      </div>
    );
  }

  if (admin === false) {
    return (
      <div className="flex min-h-screen items-start justify-center bg-slate-50 px-6 py-16">
        <div className="max-w-lg rounded-2xl border border-amber-200 bg-amber-50 p-8 text-center">
          <div className="text-3xl">🔒</div>
          <h1 className="mt-3 text-lg font-semibold text-amber-900">
            Admins only
          </h1>
          <p className="mt-2 text-sm text-amber-800">
            Your account is not marked as admin yet. Grant access in SQL:
          </p>
          <code className="mt-3 block rounded-lg bg-amber-100 px-3 py-2 text-xs text-amber-900">
            update public.profiles set is_admin = true where id = auth.uid();
          </code>
        </div>
      </div>
    );
  }

  // ── admin sheet ───────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-100 px-6 py-8">
      <div className="mx-auto max-w-7xl">
        {/* header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-semibold text-slate-900">
              📋 Feedback — admin sheet
            </h1>
            <p className="mt-0.5 text-sm text-slate-500">
              {counts.total} row{counts.total === 1 ? "" : "s"} ·{" "}
              <span className="text-amber-600">{counts.new} new</span> ·{" "}
              <span className="text-blue-600">{counts.reviewed} reviewed</span> ·{" "}
              <span className="text-green-600">{counts.resolved} resolved</span>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search feedback…"
              className="w-52 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
            />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none"
            >
              <option value="all">All statuses</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
            <button
              onClick={load}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
            >
              Refresh
            </button>
            <button
              onClick={() =>
                downloadCsv(
                  `feedback-${new Date().toISOString().slice(0, 10)}.csv`,
                  feedbackToCsv(sorted)
                )
              }
              className="rounded-lg bg-green-600 px-3 py-2 text-sm font-medium text-white hover:bg-green-700"
            >
              ⬇ Export CSV → Google Sheets
            </button>
          </div>
        </div>

        {/* error */}
        {error ? (
          <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        {/* the sheet */}
        <div className="mt-4 overflow-hidden rounded-xl border border-slate-300 bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-slate-200 text-left text-xs uppercase tracking-wide text-slate-600">
                  <th className="w-10 border-b border-r border-slate-300 px-2 py-2.5 text-center font-semibold text-slate-400">
                    #
                  </th>
                  {COLUMNS.map((col) => (
                    <th
                      key={col.key}
                      onClick={() => toggleSort(col.key)}
                      className="cursor-pointer select-none border-b border-r border-slate-300 px-3 py-2.5 font-semibold hover:bg-slate-300/50"
                    >
                      {col.label}
                      {sortKey === col.key ? (sortAsc ? " ▲" : " ▼") : ""}
                    </th>
                  ))}
                  <th className="border-b border-slate-300 px-3 py-2.5 font-semibold">
                    Admin note
                  </th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={9} className="px-4 py-10 text-center text-slate-400">
                      Loading…
                    </td>
                  </tr>
                ) : sorted.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="px-4 py-10 text-center text-slate-400">
                      No feedback rows yet — submissions from /feedback appear here
                      instantly.
                    </td>
                  </tr>
                ) : (
                  sorted.map((row, i) => (
                    <tr
                      key={row.id}
                      className={i % 2 === 1 ? "bg-slate-50" : "bg-white"}
                    >
                      <td className="border-b border-r border-slate-200 px-2 py-2 text-center text-xs text-slate-400">
                        {i + 1}
                      </td>
                      <td className="whitespace-nowrap border-b border-r border-slate-200 px-3 py-2 text-slate-600">
                        {formatDateTime(row.created_at)}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2 text-slate-900">
                        {row.name}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2 text-slate-600">
                        {row.email}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2">
                        <StarRating value={row.rating} size="text-sm" />
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2">
                        <span className="rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-medium text-indigo-700">
                          {row.category}
                        </span>
                      </td>
                      <td className="min-w-[260px] border-b border-r border-slate-200 px-3 py-2 text-slate-800">
                        {row.message}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2">
                        <select
                          value={row.status}
                          onChange={(e) => changeStatus(row.id, e.target.value)}
                          className={`rounded-full border-0 px-2 py-1 text-xs font-semibold outline-none ${STATUS_STYLES[row.status]}`}
                        >
                          {STATUSES.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="border-b border-slate-200 px-2 py-1.5">
                        <input
                          defaultValue={row.admin_note ?? ""}
                          placeholder="Add note…"
                          onBlur={(e) =>
                            e.target.value !== (row.admin_note ?? "") &&
                            updateFeedback(row.id, { adminNote: e.target.value })
                          }
                          className="w-full rounded-md border border-transparent bg-transparent px-2 py-1 text-xs text-slate-700 outline-none hover:border-slate-300 focus:border-indigo-400 focus:bg-white"
                        />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <p className="mt-3 text-xs text-slate-400">
          Tip: “Export CSV” downloads a file that opens directly in Google Sheets
          — or share the CSV with anyone. Rows cap at the latest 500.
        </p>
      </div>
    </div>
  );
}
