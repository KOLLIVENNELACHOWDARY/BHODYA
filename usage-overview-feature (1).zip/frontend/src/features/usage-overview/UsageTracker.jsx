import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { useUsageTracker } from "./useUsageTracker";
import { logPageView } from "./api";

/**
 * Invisible, always-mounted component that:
 *   1. auto-tracks active time  (via useUsageTracker)
 *   2. logs a page view on every route change
 *
 * Mount it ONCE inside the router, e.g. in App.jsx:
 *
 *   import UsageOverviewPage, { UsageTracker } from "./features/usage-overview";
 *   ...
 *   <Router>
 *     <UsageTracker />
 *     <Routes> ... </Routes>
 *   </Router>
 */
export default function UsageTracker() {
  const location = useLocation();
  useUsageTracker();

  useEffect(() => {
    logPageView(location.pathname).catch(() => {});
  }, [location.pathname]);

  return null;
}
