import { pageLabel } from "../api";
import { timeAgo } from "../utils";

/**
 * Latest pages the user visited.
 * `items`: [{ id, page, visited_at }]
 */
export default function RecentActivity({ items }) {
  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
      <h2 className="text-sm font-semibold text-slate-900">Recent activity</h2>

      {items.length === 0 ? (
        <p className="mt-4 text-sm text-slate-500">
          Nothing tracked yet — start exploring and your visits will show up here.
        </p>
      ) : (
        <ul className="mt-3 space-y-2">
          {items.map((v) => (
            <li
              key={v.id}
              className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2"
            >
              <span className="flex items-center gap-2 text-sm text-slate-700">
                <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" />
                {pageLabel(v.page)}
              </span>
              <span className="text-xs text-slate-400">{timeAgo(v.visited_at)}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
