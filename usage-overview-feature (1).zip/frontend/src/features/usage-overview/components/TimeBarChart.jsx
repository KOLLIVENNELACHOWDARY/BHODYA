import { formatDuration } from "../utils";

/**
 * Pure-CSS bar chart of active time for the last 7 days.
 * `days`: [{ date, shortLabel, seconds }]
 */
export default function TimeBarChart({ days }) {
  const max = Math.max(60, ...days.map((d) => d.seconds)); // scale floor: 1 min

  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
      <h2 className="text-sm font-semibold text-slate-900">
        Active time — last 7 days
      </h2>
      <div className="mt-4 flex h-40 items-end gap-2">
        {days.map((d) => (
          <div key={d.date} className="flex flex-1 flex-col items-center gap-1">
            <span className="text-[10px] tabular-nums text-slate-500">
              {d.seconds > 0 ? formatDuration(d.seconds) : ""}
            </span>
            <div
              className={`w-full rounded-t-md transition-all ${
                d.seconds > 0 ? "bg-indigo-500" : "bg-slate-200"
              }`}
              style={{
                height: `${Math.max(4, (d.seconds / max) * 100)}%`,
              }}
            />
            <span className="text-xs text-slate-500">{d.shortLabel}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
