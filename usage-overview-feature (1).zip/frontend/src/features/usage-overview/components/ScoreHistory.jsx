import { scorePct } from "../api";
import { formatDate } from "../utils";

function pctBadge(pct) {
  const color =
    pct >= 75
      ? "bg-green-100 text-green-700"
      : pct >= 40
        ? "bg-amber-100 text-amber-700"
        : "bg-red-100 text-red-700";
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${color}`}>
      {pct}%
    </span>
  );
}

/**
 * Recent quiz / game scores.
 * `attempts`: [{ id, score, max_score, created_at }]
 */
export default function ScoreHistory({ attempts }) {
  return (
    <div className="rounded-2xl bg-white p-5 shadow-sm ring-1 ring-slate-200">
      <h2 className="text-sm font-semibold text-slate-900">Score history</h2>

      {attempts.length === 0 ? (
        <p className="mt-4 text-sm text-slate-500">
          No quiz or game attempts yet — play a Boss Battle to see scores here!
        </p>
      ) : (
        <table className="mt-3 w-full text-left text-sm">
          <thead>
            <tr className="text-xs uppercase tracking-wide text-slate-400">
              <th className="pb-2 font-medium">Date</th>
              <th className="pb-2 font-medium">Score</th>
              <th className="pb-2 text-right font-medium">Percent</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {attempts.map((a) => {
              const pct = scorePct(a);
              return (
                <tr key={a.id}>
                  <td className="py-2 text-slate-600">{formatDate(a.created_at)}</td>
                  <td className="py-2 tabular-nums text-slate-900">
                    {a.score}
                    {a.max_score ? ` / ${a.max_score}` : ""}
                  </td>
                  <td className="py-2 text-right">{pctBadge(pct)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}
