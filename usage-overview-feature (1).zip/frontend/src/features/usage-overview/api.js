import { supabase } from "../../supabaseClient";

// ─────────────────────────────────────────────────────────────────────────────
// Data access for the Usage Overview feature (Supabase-only — no FastAPI).
//
// Tables used:
//   public.time_logs   + public.page_views  → see supabase/migrations/0002_usage_tracking.sql
//   public.quiz_attempts                    → already exists (0001_init.sql).
//     If your column names differ, just change QUIZ_ATTEMPT_COLUMNS below.
// ─────────────────────────────────────────────────────────────────────────────

const QUIZ_ATTEMPT_COLUMNS = "id, score, max_score, created_at";

// Routes that count as "games / quizzes / tests" when counting visits.
const GAME_PAGE_REGEX = /(quiz|boss|game|test|battle|assessment)/i;

// Friendly names for known feature routes (fallback: show the raw path).
const PAGE_LABELS = {
  "/": "Home",
  "/dashboard": "Dashboard",
  "/onboarding": "Onboarding tour",
  "/knowledge-graph": "Knowledge graph",
  "/tutor": "Tutor chat",
  "/quizzes": "Boss Battle quizzes",
  "/tests": "Tests & assessment",
  "/revision": "Revision tools",
  "/schedule": "Study schedule",
  "/todos": "To-do list",
  "/time-tracking": "Time tracking",
  "/files": "Files & RAG",
  "/rooms": "Collab rooms",
  "/rewards": "Streaks & rewards",
  "/overview": "Usage overview",
};

export function pageLabel(page) {
  return PAGE_LABELS[page] ?? page;
}

// ── local date helpers (day buckets must use the user's timezone) ────────────

function dayKey(d) {
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function buildLast7Days() {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    days.push({
      date: dayKey(d),
      shortLabel: d.toLocaleDateString(undefined, { weekday: "short" }),
    });
  }
  return days;
}

// ── auth ────────────────────────────────────────────────────────────────────

async function currentUserId() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user?.id ?? null;
}

/** Percentage score of a quiz attempt (handles score/max_score vs 0-100). */
export function scorePct(attempt) {
  const max = attempt.max_score ?? 0;
  if (max > 0) return Math.round((attempt.score / max) * 100);
  return Math.round(attempt.score ?? 0);
}

// ── write: called by the tracker ────────────────────────────────────────────

/** Append a slice of active time (seconds) to `time_logs`. */
export async function logTimeSlice(activeSeconds) {
  const userId = await currentUserId();
  if (!userId || !activeSeconds) return null;
  const { error } = await supabase
    .from("time_logs")
    .insert({ user_id: userId, active_seconds: activeSeconds });
  if (error) throw error;
}

/** Record one page visit in `page_views`. */
export async function logPageView(page) {
  const userId = await currentUserId();
  if (!userId) return null;
  const { error } = await supabase
    .from("page_views")
    .insert({ user_id: userId, page });
  if (error) throw error;
}

// ── read: called by the overview page ───────────────────────────────────────

/**
 * Aggregated "superficial" overview:
 *   time used (total / today / this week / last-7-days buckets),
 *   pages visited (total, distinct, game-quiz visits),
 *   quiz & game scores (count, average %, best %, history).
 */
export async function getUsageSummary() {
  const userId = await currentUserId();
  if (!userId) throw new Error("Sign in to see your usage overview.");

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const [allTime, recentTime, pages, attempts] = await Promise.all([
    supabase
      .from("time_logs")
      .select("active_seconds", { count: "exact" })
      .eq("user_id", userId)
      .limit(5000),
    supabase
      .from("time_logs")
      .select("active_seconds, created_at")
      .eq("user_id", userId)
      .gte("created_at", weekAgo.toISOString())
      .limit(2000),
    supabase
      .from("page_views")
      .select("id, page, visited_at", { count: "exact" })
      .eq("user_id", userId)
      .order("visited_at", { ascending: false })
      .limit(500),
    supabase
      .from("quiz_attempts")
      .select(QUIZ_ATTEMPT_COLUMNS, { count: "exact" })
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(200),
  ]);

  for (const res of [allTime, recentTime, pages, attempts]) {
    if (res.error) throw res.error;
  }

  // ── time used ────────────────────────────────────────────────────────────
  const totalSeconds = (allTime.data ?? []).reduce(
    (sum, row) => sum + (row.active_seconds ?? 0),
    0
  );

  let todaySeconds = 0;
  let weekSeconds = 0;
  const byDay = new Map(); // 'YYYY-MM-DD' -> seconds
  for (const row of recentTime.data ?? []) {
    const secs = row.active_seconds ?? 0;
    const created = new Date(row.created_at);
    if (created >= startOfToday) todaySeconds += secs;
    if (created >= weekAgo) weekSeconds += secs;
    const key = dayKey(created);
    byDay.set(key, (byDay.get(key) ?? 0) + secs);
  }
  const last7Days = buildLast7Days().map((d) => ({
    ...d,
    seconds: byDay.get(d.date) ?? 0,
  }));

  // ── page views ───────────────────────────────────────────────────────────
  const viewRows = pages.data ?? [];
  const pageViewsTotal = pages.count ?? viewRows.length;
  const distinctPages = new Set(viewRows.map((r) => r.page)).size;
  const gameVisits = viewRows.filter((r) => GAME_PAGE_REGEX.test(r.page)).length;
  const recentActivity = viewRows.slice(0, 15);

  // ── quiz / game scores ───────────────────────────────────────────────────
  const attemptRows = attempts.data ?? [];
  const quizAttempts = attempts.count ?? attemptRows.length;
  const pcts = attemptRows.map(scorePct);
  const avgScorePct = pcts.length
    ? Math.round(pcts.reduce((a, b) => a + b, 0) / pcts.length)
    : null;
  const bestScorePct = pcts.length ? Math.max(...pcts) : null;

  return {
    totalSeconds,
    todaySeconds,
    weekSeconds,
    last7Days,
    pageViewsTotal,
    distinctPages,
    gameVisits,
    recentActivity,
    quizAttempts,
    avgScorePct,
    bestScorePct,
    scoreHistory: attemptRows.slice(0, 20),
  };
}
