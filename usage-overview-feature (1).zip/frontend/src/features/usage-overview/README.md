# Usage Overview — superficial activity tracking

Implements **FEATURE_MODULE_MAP #15 (Time tracking)** + **#21 (Progress tracking)**
as one screen: `/overview`.

## What it shows

| Stat | Meaning |
|---|---|
| ⏱️ Time used | Total active time + today + this week (auto-tracked, pauses when the tab is hidden) |
| 📄 Pages visited | How many pages the user opened (all feature pages), and how many distinct ones |
| 🎮 Games & quizzes visited | Visits to quiz / boss-battle / test / game routes + completed attempts |
| 🏆 Scores | Average % and best % across quiz/game attempts + full score history table |

Plus: a **7-day active-time bar chart** and a **recent-activity feed**.

## Files

| File | Purpose |
|---|---|
| `index.jsx` | The `/overview` page (default export) + re-exports `UsageTracker` |
| `UsageTracker.jsx` | Invisible component: logs page views on every route change + auto time tracking. Mount ONCE inside the router |
| `useUsageTracker.js` | Hook that counts active seconds (tab visible) and flushes a `time_logs` slice every 60s / on hide / on unmount |
| `api.js` | All Supabase reads/writes (`time_logs`, `page_views`, reads `quiz_attempts`) |
| `utils.js` | Duration/date formatting helpers |
| `components/` | `StatCard`, `TimeBarChart`, `ScoreHistory`, `RecentActivity` |
| `supabase/migrations/0002_usage_tracking.sql` | New tables + RLS (at repo root, next to `0001_init.sql`) |

## Setup

**1. Apply the migration** (`supabase/migrations/0002_usage_tracking.sql`) —
creates `time_logs` + `page_views` with row-level security (users only see
their own rows).

**2. Wire up `App.jsx`** (the only file outside this folder you touch):

```jsx
import UsageOverviewPage, { UsageTracker } from "./features/usage-overview";

// inside your router:
<Router>
  <UsageTracker />           {/* invisible: active time + page view logging */}
  <Routes>
    {/* ...your existing routes... */}
    <Route path="/overview" element={<UsageOverviewPage />} />
  </Routes>
</Router>
```

Add a nav link to `/overview` wherever your sidebar/menu lives.

**3. Done.** Time and page views start flowing automatically for signed-in
users; scores appear as soon as rows exist in `quiz_attempts`.

## Assumptions (adjust if your schema differs)

- `quiz_attempts` has columns `id, score, max_score, created_at, user_id`
  (edit `QUIZ_ATTEMPT_COLUMNS` at the top of `api.js` if not).
- Percentage = `score / max_score * 100`; if `max_score` is null, `score` is
  treated as already being a percentage.
- "Games & quizzes" pages are matched by URL: anything containing
  `quiz | boss | game | test | battle | assessment` (see `GAME_PAGE_REGEX`).
- Imports assume `supabaseClient.js` lives at `frontend/src/supabaseClient.js`.
- Frontend-only feature — no FastAPI router needed (all Supabase, like
  FEATURE_MODULE_MAP's "Supabase only" rows).

## Nice-to-haves later

- Swap `PAGE_LABELS` to use `AgeContext` wording (child / teen / adult).
- Server-side aggregation via a Postgres view/RPC once data grows.
- Daily streak badges using `time_logs` day buckets.
