import { useEffect, useRef } from "react";
import { logTimeSlice } from "./api";

/** Count one second of active time on every tick. */
const TICK_MS = 1000;
/** Push a slice to Supabase once a minute of accumulated active time. */
const FLUSH_AFTER_SECONDS = 60;

/**
 * Auto-tracks "active time":
 *   +1s every second while the tab is visible, paused while hidden.
 * Buffered seconds are flushed to `time_logs`:
 *   - every 60s of active time,
 *   - when the tab becomes hidden,
 *   - on tab close (pagehide) and on unmount.
 *
 * Usage: `useUsageTracker();` inside any always-mounted component.
 * The exported `<UsageTracker />` component does this for you.
 */
export function useUsageTracker() {
  const bufferRef = useRef(0);
  const secondsSinceFlushRef = useRef(0);

  useEffect(() => {
    const flush = () => {
      const secs = bufferRef.current;
      if (secs <= 0) return;
      bufferRef.current = 0;
      secondsSinceFlushRef.current = 0;
      // fire-and-forget — tracking must never block or break the app
      logTimeSlice(secs).catch(() => {});
    };

    const interval = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      bufferRef.current += 1;
      secondsSinceFlushRef.current += 1;
      if (secondsSinceFlushRef.current >= FLUSH_AFTER_SECONDS) flush();
    }, TICK_MS);

    const onVisibilityChange = () => {
      if (document.visibilityState === "hidden") flush();
    };

    document.addEventListener("visibilitychange", onVisibilityChange);
    window.addEventListener("pagehide", flush);

    return () => {
      clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      window.removeEventListener("pagehide", flush);
      flush();
    };
  }, []);
}
