import { useCallback, useEffect, useState } from "react";
import { getUsageSummary } from "./api";
import StatCard from "./components/StatCard";
import TimeBarChart from "./components/TimeBarChart";
import ScoreHistory from "./components/ScoreHistory";
import RecentActivity from "./components/RecentActivity";
import { formatDuration } from "./utils";

// Invisible app-wide tracker (active time + page views) — mount in App.jsx.
export { default as UsageTracker } from "./UsageTracker";

/**
 * `/overview` — "superficial" usage tracking:
 *   ⏱  how much time the user used the app (total / today / this week)
 *   📄  how many pages were visited (incl. games & quizzes)
 *   🏆  quiz & game scores (average, best, history)
 */
export default function UsageOverviewPage() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setSummary(await getUsageSummary());
    } catch (err) {
      setError(err?.message ?? "Failed to load usage data.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="min-h-screen bg-slate-50 px-6 py-8">
      <div className="mx-auto max-w-5xl">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900">
              Your usage overview
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              Time spent, pages &amp; games visited, and your scores — all at a
              glance.
            </p>
          </div>
          <button
            onClick={load}
            disabled={loading}
            className="rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-medium text-white transition hover:bg-indigo-700 disabled:opacity-50"
          >
            {loading ? "Loading…" : "Refresh"}
          </button>
        </div>

        {/* Body */}
        {error ? (
          <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            {error}
          </div>
        ) : loading && !summary ? (
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-28 animate-pulse rounded-2xl bg-slate-200/60"
              />
            ))}
          </div>
        ) : summary ? (
          <>
            {/* Stat cards */}
            <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <StatCard
                icon="⏱️"
                label="Time used"
                value={formatDuration(summary.totalSeconds)}
                sub={`today ${formatDuration(summary.todaySeconds)} · this week ${formatDuration(summary.weekSeconds)}`}
              />
              <StatCard
                icon="📄"
                label="Pages visited"
                value={summary.pageViewsTotal.toLocaleString()}
                sub={`${summary.distinctPages} different pages tracked`}
              />
              <StatCard
                icon="🎮"
                label="Games & quizzes visited"
                value={summary.gameVisits.toLocaleString()}
                sub={`${summary.quizAttempts} quiz/game attempt${summary.quizAttempts === 1 ? "" : "s"} completed`}
              />
              <StatCard
                icon="🏆"
                label="Scores"
                value={
                  summary.avgScorePct === null ? "—" : `${summary.avgScorePct}% avg`
                }
                sub={
                  summary.bestScorePct === null
                    ? "play a quiz to earn a score"
                    : `best ${summary.bestScorePct}%`
                }
              />
            </div>

            {/* Chart + score history */}
            <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
              <TimeBarChart days={summary.last7Days} />
              <ScoreHistory attempts={summary.scoreHistory} />
            </div>

            {/* Recent activity */}
            <div className="mt-6">
              <RecentActivity items={summary.recentActivity} />
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}
