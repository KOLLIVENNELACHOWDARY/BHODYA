-- Usage tracking tables for the "Usage Overview" feature
-- (FEATURE_MODULE_MAP #15 time tracking + #21 progress tracking).
--
--   time_logs   — one row per flushed slice of *active* app time (tab visible).
--   page_views  — one row per visited route / feature page.
--
-- Quiz & game scores are NOT stored here — they are read from the existing
-- `quiz_attempts` table created in 0001_init.sql.

create table if not exists public.time_logs (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users (id) on delete cascade,
  active_seconds integer not null check (active_seconds > 0),
  -- when the tracked slice started (client clock is fine for a superficial overview)
  started_at     timestamptz not null default now(),
  created_at     timestamptz not null default now()
);

create table if not exists public.page_views (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users (id) on delete cascade,
  page       text not null,
  visited_at timestamptz not null default now()
);

create index if not exists time_logs_user_created_idx
  on public.time_logs (user_id, created_at desc);

create index if not exists page_views_user_visited_idx
  on public.page_views (user_id, visited_at desc);

alter table public.time_logs  enable row level security;
alter table public.page_views enable row level security;

-- Users may only read/append their own usage rows.
create policy "time_logs_select_own"
  on public.time_logs for select
  using (auth.uid() = user_id);

create policy "time_logs_insert_own"
  on public.time_logs for insert
  with check (auth.uid() = user_id);

create policy "page_views_select_own"
  on public.page_views for select
  using (auth.uid() = user_id);

create policy "page_views_insert_own"
  on public.page_views for insert
  with check (auth.uid() = user_id);
