-- App reviews (FEATURE_MODULE_MAP #23 — Suggestions & Reviews).
-- Users submit ⭐ reviews of the app; ALL reviews are stored and seen
-- on the admin side (/admin/reviews).
--
--   users  → /reviews          → submit / edit / delete their own review
--   admin  → /admin/reviews    → spreadsheet + rating stats + triage
--
-- NOTE: ARCHITECTURE.md lists a `reviews` table in 0001_init.sql — this
-- migration is defensive: `create if not exists` + `add column if not exists`,
-- so it is safe whether or not 0001 already made the table.

create table if not exists public.reviews (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users (id) on delete cascade,
  name       text,
  email      text,
  rating     integer not null check (rating between 1 and 5),
  title      text,
  message    text not null check (char_length(message) between 1 and 4000),
  status     text not null default 'new'
             check (status in ('new', 'approved', 'hidden')),
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- in case 0001 created `reviews` with a different shape
alter table public.reviews add column if not exists name       text;
alter table public.reviews add column if not exists email      text;
alter table public.reviews add column if not exists title      text;
alter table public.reviews add column if not exists status     text
  not null default 'new';
alter table public.reviews add column if not exists admin_note text;
alter table public.reviews add column if not exists updated_at timestamptz
  not null default now();

create index if not exists reviews_created_idx on public.reviews (created_at desc);
create index if not exists reviews_status_idx  on public.reviews (status);
create index if not exists reviews_user_idx    on public.reviews (user_id);

-- ── admin helper (also created in 0003_feedback.sql — safe to replace) ─────
alter table public.profiles
  add column if not exists is_admin boolean not null default false;

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false);
$$;

grant execute on function public.is_admin() to authenticated;

-- ── RLS ─────────────────────────────────────────────────────────────────────
-- Users: insert / see / edit / delete ONLY their own review.
-- Admins: see / triage / delete ALL reviews (the stored admin side).
alter table public.reviews enable row level security;

drop policy if exists "reviews_insert_own"   on public.reviews;
drop policy if exists "reviews_select_own"   on public.reviews;
drop policy if exists "reviews_update_own"   on public.reviews;
drop policy if exists "reviews_delete_own"   on public.reviews;
drop policy if exists "reviews_admin_select" on public.reviews;
drop policy if exists "reviews_admin_update" on public.reviews;
drop policy if exists "reviews_admin_delete" on public.reviews;

create policy "reviews_insert_own"
  on public.reviews for insert
  to authenticated
  with check (auth.uid() = user_id);

create policy "reviews_select_own"
  on public.reviews for select
  using (auth.uid() = user_id);

create policy "reviews_update_own"
  on public.reviews for update
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create policy "reviews_delete_own"
  on public.reviews for delete
  using (auth.uid() = user_id);

create policy "reviews_admin_select"
  on public.reviews for select
  using (public.is_admin());

create policy "reviews_admin_update"
  on public.reviews for update
  using (public.is_admin())
  with check (public.is_admin());

create policy "reviews_admin_delete"
  on public.reviews for delete
  using (public.is_admin());

-- ── grant yourself admin (run once) ─────────────────────────────────────────
-- update public.profiles set is_admin = true where id = auth.uid();
