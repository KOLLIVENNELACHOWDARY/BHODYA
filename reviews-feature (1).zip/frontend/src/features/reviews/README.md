# App Reviews — user review form + admin-side storage

Implements **FEATURE_MODULE_MAP #23 (Suggestions & Reviews)** — the *review*
half (the private feedback inbox lives in `features/feedback`).

Users leave an app-store-style review (⭐ 1–5 + title + text). **Every review is
stored on the admin side** — users only ever see their own; admins see all.

| Side | Route | What it does |
|---|---|---|
| 👤 User page | `/reviews` | ⭐ star rating + optional title + review text · one review per user (edit / delete anytime) |
| 🗄️ Admin page | `/admin/reviews` | **All reviews stored here**: average rating + star histogram + Google-Sheets-style grid (sortable, search, status triage, admin notes, CSV export) |

## Files

| File | Purpose |
|---|---|
| `index.jsx` | User review page (default export) + re-exports `AdminReviewsSheet` |
| `AdminReviewsSheet.jsx` | Admin storage: stats + histogram + spreadsheet |
| `api.js` | Supabase CRUD (submit / my review / admin fetch & triage) |
| `utils.js` | CSV export (opens in Google Sheets) + date formatting |
| `components/StarRating.jsx` | 1–5 stars (editable / read-only) |
| `supabase/migrations/0006_reviews.sql` | `reviews` table + RLS + `is_admin` helper |

## Setup

**1. Migration** — run `supabase/migrations/0006_reviews.sql`
(defensive: safe if `0001_init.sql` already created `reviews`, and safe if
`0003_feedback.sql` already added `is_admin` / `is_admin()`).

**2. Make yourself admin** (once, Supabase SQL editor):

```sql
update public.profiles set is_admin = true where id = auth.uid();
```

**3. Wire up `App.jsx`** (the only file outside this folder you touch):

```jsx
import ReviewsPage, { AdminReviewsSheet } from "./features/reviews";

<Routes>
  {/* ...your existing routes... */}
  <Route path="/reviews" element={<ReviewsPage />} />
  <Route path="/admin/reviews" element={<AdminReviewsSheet />} />
</Routes>
```

Nav links: “Write a review” for everyone, “Reviews admin” for admins.
**No FastAPI needed** — reviews are plain CRUD, so per ARCHITECTURE.md the
frontend talks to Supabase directly (`routers/reviews.py` is not required).

## Data model (`public.reviews`)

| Column | Meaning |
|---|---|
| `rating` | 1–5 stars (required) |
| `title` | optional short headline |
| `message` | the review text (1–4000 chars) |
| `status` | `new` → `approved` → `hidden` (admin-controlled) |
| `admin_note` | private admin annotation |
| `name` / `email` | copied from the auth user on submit |

## RLS rules (why "stored on the admin side")

- users: **insert / select / update / delete ONLY their own** review
- admins (`profiles.is_admin`): **select / update / delete ALL**
- nobody else can read anything — enforced in the database, not just the UI

## Assumptions / notes

- One review per user is the intended UX (the page shows "your review" with
  edit/delete); the table allows multiple rows but the UI keeps the latest.
- Status meanings: **new** = just arrived · **approved** = good to publish
  later · **hidden** = inappropriate. If you later want a public review wall,
  read `status = 'approved'` rows and render them read-only.
- Imports assume `supabaseClient.js` sits at `frontend/src/supabaseClient.js`.
- Optional future upgrade: a tiny `routers/reviews.py` AI digest
  ("users love X, complain about Y") summarising review text — say the word
  and it can be added.
