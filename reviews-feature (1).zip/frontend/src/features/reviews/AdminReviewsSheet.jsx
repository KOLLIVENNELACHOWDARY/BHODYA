import { useCallback, useEffect, useMemo, useState } from "react";
import {
  fetchReviews,
  updateReview,
  adminDeleteReview,
  isAdmin,
  STATUSES,
} from "./api";
import { reviewsToCsv, downloadCsv, formatDateTime } from "./utils";
import StarRating from "./components/StarRating";

const STATUS_STYLES = {
  new: "bg-amber-100 text-amber-700",
  approved: "bg-green-100 text-green-700",
  hidden: "bg-slate-200 text-slate-600",
};

const COLUMNS = [
  { key: "created_at", label: "Received" },
  { key: "name", label: "Name" },
  { key: "email", label: "Email" },
  { key: "rating", label: "Rating" },
  { key: "title", label: "Title" },
  { key: "message", label: "Review" },
  { key: "status", label: "Status" },
];

/**
 * `/admin/reviews` — where ALL app reviews are stored (admin-only).
 * Rating stats + star histogram on top, Google-Sheets-style grid below.
 */
export default function AdminReviewsSheet() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortKey, setSortKey] = useState("created_at");
  const [sortAsc, setSortAsc] = useState(false);
  const [admin, setAdmin] = useState(null); // null = checking

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setRows(await fetchReviews({ status: statusFilter, search }));
    } catch (err) {
      setError(err?.message ?? "Failed to load reviews.");
    } finally {
      setLoading(false);
    }
  }, [statusFilter, search]);

  useEffect(() => {
    isAdmin().then(setAdmin);
  }, []);

  useEffect(() => {
    if (admin) load();
  }, [admin, load]);

  // ── stats ────────────────────────────────────────────────────────────────
  const stats = useMemo(() => {
    const total = rows.length;
    const byStar = [5, 4, 3, 2, 1].map((star) => ({
      star,
      count: rows.filter((r) => r.rating === star).length,
    }));
    const avg = total
      ? rows.reduce((sum, r) => sum + r.rating, 0) / total
      : 0;
    return {
      total,
      avg,
      byStar,
      counts: {
        new: rows.filter((r) => r.status === "new").length,
        approved: rows.filter((r) => r.status === "approved").length,
        hidden: rows.filter((r) => r.status === "hidden").length,
      },
    };
  }, [rows]);

  const sorted = useMemo(() => {
    const list = [...rows];
    list.sort((a, b) => {
      const va = a[sortKey] ?? "";
      const vb = b[sortKey] ?? "";
      const cmp =
        typeof va === "number" && typeof vb === "number"
          ? va - vb
          : String(va).localeCompare(String(vb));
      return sortAsc ? cmp : -cmp;
    });
    return list;
  }, [rows, sortKey, sortAsc]);

  function toggleSort(key) {
    if (key === sortKey) setSortAsc(!sortAsc);
    else {
      setSortKey(key);
      setSortAsc(true);
    }
  }

  async function changeStatus(id, status) {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, status } : r)));
    try {
      await updateReview(id, { status });
    } catch (err) {
      setError(err?.message ?? "Failed to update status.");
      load();
    }
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this review permanently?")) return;
    try {
      await adminDeleteReview(id);
      await load();
    } catch (err) {
      setError(err?.message ?? "Delete failed.");
    }
  }

  // ── admin gate ────────────────────────────────────────────────────────────
  if (admin === null) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 text-sm text-slate-500">
        Checking admin access…
      </div>
    );
  }

  if (admin === false) {
    return (
      <div className="flex min-h-screen items-start justify-center bg-slate-50 px-6 py-16">
        <div className="max-w-lg rounded-2xl border border-amber-200 bg-amber-50 p-8 text-center">
          <div className="text-3xl">🔒</div>
          <h1 className="mt-3 text-lg font-semibold text-amber-900">
            Admins only
          </h1>
          <p className="mt-2 text-sm text-amber-800">
            Reviews are stored on the admin side. Grant access in SQL:
          </p>
          <code className="mt-3 block rounded-lg bg-amber-100 px-3 py-2 text-xs text-amber-900">
            update public.profiles set is_admin = true where id = auth.uid();
          </code>
        </div>
      </div>
    );
  }

  // ── admin sheet ───────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-slate-100 px-6 py-8">
      <div className="mx-auto max-w-7xl">
        {/* header */}
        <div>
          <h1 className="text-xl font-semibold text-slate-900">
            ⭐ Reviews — admin storage
          </h1>
          <p className="mt-0.5 text-sm text-slate-500">
            Every app review from every user, recorded here.{" "}
            <span className="text-amber-600">{stats.counts.new} new</span> ·{" "}
            <span className="text-green-600">{stats.counts.approved} approved</span> ·{" "}
            <span className="text-slate-500">{stats.counts.hidden} hidden</span>
          </p>
        </div>

        {/* stats + histogram */}
        <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-[240px_1fr]">
          <div className="rounded-2xl border border-slate-300 bg-white p-5 text-center">
            <div className="text-4xl font-bold text-slate-900">
              {stats.total ? stats.avg.toFixed(1) : "—"}
            </div>
            <div className="mt-1">
              <StarRating value={Math.round(stats.avg)} size="text-lg" />
            </div>
            <p className="mt-1 text-xs text-slate-400">
              average of {stats.total} review{stats.total === 1 ? "" : "s"}
            </p>
          </div>

          <div className="rounded-2xl border border-slate-300 bg-white p-5">
            {stats.byStar.map(({ star, count }) => (
              <div key={star} className="flex items-center gap-3 py-1">
                <span className="w-8 text-right text-xs text-slate-500">
                  {star} ★
                </span>
                <div className="h-3 flex-1 overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-amber-400 transition-all"
                    style={{
                      width: `${stats.total ? (count / stats.total) * 100 : 0}%`,
                    }}
                  />
                </div>
                <span className="w-8 text-xs tabular-nums text-slate-500">
                  {count}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* toolbar */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search reviews…"
            className="w-52 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none"
          >
            <option value="all">All statuses</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <button
            onClick={load}
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
          >
            Refresh
          </button>
          <button
            onClick={() =>
              downloadCsv(
                `reviews-${new Date().toISOString().slice(0, 10)}.csv`,
                reviewsToCsv(sorted)
              )
            }
            className="rounded-lg bg-green-600 px-3 py-2 text-sm font-medium text-white hover:bg-green-700"
          >
            ⬇ Export CSV → Google Sheets
          </button>
        </div>

        {/* error */}
        {error ? (
          <div className="mt-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        {/* the sheet */}
        <div className="mt-4 overflow-hidden rounded-xl border border-slate-300 bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="bg-slate-200 text-left text-xs uppercase tracking-wide text-slate-600">
                  <th className="w-10 border-b border-r border-slate-300 px-2 py-2.5 text-center font-semibold text-slate-400">
                    #
                  </th>
                  {COLUMNS.map((col) => (
                    <th
                      key={col.key}
                      onClick={() => toggleSort(col.key)}
                      className="cursor-pointer select-none border-b border-r border-slate-300 px-3 py-2.5 font-semibold hover:bg-slate-300/50"
                    >
                      {col.label}
                      {sortKey === col.key ? (sortAsc ? " ▲" : " ▼") : ""}
                    </th>
                  ))}
                  <th className="border-b border-slate-300 px-3 py-2.5 font-semibold">
                    Admin note
                  </th>
                  <th className="border-b border-slate-300 px-3 py-2.5" />
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={10} className="px-4 py-10 text-center text-slate-400">
                      Loading…
                    </td>
                  </tr>
                ) : sorted.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="px-4 py-10 text-center text-slate-400">
                      No reviews yet — submissions from /reviews appear here instantly.
                    </td>
                  </tr>
                ) : (
                  sorted.map((row, i) => (
                    <tr
                      key={row.id}
                      className={i % 2 === 1 ? "bg-slate-50" : "bg-white"}
                    >
                      <td className="border-b border-r border-slate-200 px-2 py-2 text-center text-xs text-slate-400">
                        {i + 1}
                      </td>
                      <td className="whitespace-nowrap border-b border-r border-slate-200 px-3 py-2 text-slate-600">
                        {formatDateTime(row.created_at)}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2 text-slate-900">
                        {row.name}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2 text-slate-600">
                        {row.email}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2">
                        <StarRating value={row.rating} size="text-sm" />
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2 font-medium text-slate-800">
                        {row.title ?? "—"}
                      </td>
                      <td className="min-w-[260px] border-b border-r border-slate-200 px-3 py-2 text-slate-800">
                        {row.message}
                      </td>
                      <td className="border-b border-r border-slate-200 px-3 py-2">
                        <select
                          value={row.status}
                          onChange={(e) => changeStatus(row.id, e.target.value)}
                          className={`rounded-full border-0 px-2 py-1 text-xs font-semibold outline-none ${STATUS_STYLES[row.status]}`}
                        >
                          {STATUSES.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="border-b border-slate-200 px-2 py-1.5">
                        <input
                          defaultValue={row.admin_note ?? ""}
                          placeholder="Add note…"
                          onBlur={(e) =>
                            e.target.value !== (row.admin_note ?? "") &&
                            updateReview(row.id, { adminNote: e.target.value })
                          }
                          className="w-full rounded-md border border-transparent bg-transparent px-2 py-1 text-xs text-slate-700 outline-none hover:border-slate-300 focus:border-indigo-400 focus:bg-white"
                        />
                      </td>
                      <td className="border-b border-slate-200 px-2 py-1.5 text-right">
                        <button
                          onClick={() => handleDelete(row.id)}
                          title="Delete review"
                          className="rounded-lg px-2 py-1 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
                        >
                          🗑
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        <p className="mt-3 text-xs text-slate-400">
          Tip: “Export CSV” opens directly in Google Sheets. Status meanings —
          <b> new</b>: just arrived · <b>approved</b>: good to publish later ·
          <b> hidden</b>: inappropriate. Rows cap at the latest 500.
        </p>
      </div>
    </div>
  );
}
