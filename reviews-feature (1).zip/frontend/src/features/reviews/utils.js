/** "Sep 27, 14:05" */
export function formatDateTime(iso) {
  return new Date(iso).toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** Escape one CSV cell. */
function csvCell(value) {
  const s = String(value ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/**
 * Build a CSV from review rows.
 * Opens directly in Google Sheets (File → Import, or double-click the file).
 */
export function reviewsToCsv(rows) {
  const header = [
    "Received",
    "Name",
    "Email",
    "Rating",
    "Title",
    "Review",
    "Status",
    "Admin note",
  ];
  const lines = [header.map(csvCell).join(",")];
  for (const r of rows) {
    lines.push(
      [r.created_at, r.name, r.email, r.rating, r.title, r.message, r.status, r.admin_note]
        .map(csvCell)
        .join(",")
    );
  }
  return lines.join("\n");
}

/** Trigger a browser download of `csv`. */
export function downloadCsv(filename, csv) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
