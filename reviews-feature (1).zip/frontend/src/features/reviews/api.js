import { supabase } from "../../supabaseClient";

// ─────────────────────────────────────────────────────────────────────────────
// App reviews (FEATURE_MODULE_MAP #23). Supabase-only — plain CRUD, so per
// ARCHITECTURE.md no FastAPI is needed (no `routers/reviews.py` required).
//
//   users:  submitReview / getMyReview / updateMyReview / deleteMyReview
//   admin:  fetchReviews / updateReview   (all rows, stored admin-side)
//
// Table: public.reviews (0006_reviews.sql) · admin gate: profiles.is_admin
// ─────────────────────────────────────────────────────────────────────────────

const REVIEW_COLUMNS =
  "id, user_id, name, email, rating, title, message, status, admin_note, created_at, updated_at";

export const STATUSES = ["new", "approved", "hidden"];

const STATUS_LABELS = {
  new: "new",
  approved: "approved",
  hidden: "hidden",
};

export function statusLabel(status) {
  return STATUS_LABELS[status] ?? status;
}

async function currentUser() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user ?? null;
}

/** True when the signed-in user has profiles.is_admin = true. */
export async function isAdmin() {
  const user = await currentUser();
  if (!user) return false;
  const { data, error } = await supabase
    .from("profiles")
    .select("is_admin")
    .eq("id", user.id)
    .single();
  if (error) return false;
  return Boolean(data?.is_admin);
}

// ── user side: own review ───────────────────────────────────────────────────

/** The signed-in user's review (latest), or null. */
export async function getMyReview() {
  const user = await currentUser();
  if (!user) throw new Error("Please sign in.");
  const { data, error } = await supabase
    .from("reviews")
    .select(REVIEW_COLUMNS)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(1);
  if (error) throw error;
  return data?.[0] ?? null;
}

/** Submit a new app review. */
export async function submitReview({ rating, title, message }) {
  const user = await currentUser();
  if (!user) throw new Error("Please sign in to leave a review.");

  const { error } = await supabase.from("reviews").insert({
    user_id: user.id,
    name:
      user.user_metadata?.full_name ??
      user.user_metadata?.name ??
      user.email?.split("@")[0] ??
      "Anonymous",
    email: user.email ?? "",
    rating,
    title: title?.trim() || null,
    message: message.trim(),
  });
  if (error) throw error;
}

/** Edit your own review. */
export async function updateMyReview(id, { rating, title, message }) {
  const { error } = await supabase
    .from("reviews")
    .update({
      rating,
      title: title?.trim() || null,
      message: message.trim(),
      updated_at: new Date().toISOString(),
    })
    .eq("id", id);
  if (error) throw error;
}

/** Delete your own review. */
export async function deleteMyReview(id) {
  const { error } = await supabase.from("reviews").delete().eq("id", id);
  if (error) throw error;
}

// ── admin side: all reviews (the storage) ───────────────────────────────────

/**
 * Fetch every review for the admin sheet (newest first).
 * `status`: "all" | "new" | "approved" | "hidden"
 * `search`: free text matched against name / email / title / message.
 */
export async function fetchReviews({ status = "all", search = "" } = {}) {
  let query = supabase
    .from("reviews")
    .select(REVIEW_COLUMNS)
    .order("created_at", { ascending: false })
    .limit(500);

  if (status !== "all") query = query.eq("status", status);

  const q = search.trim();
  if (q) {
    const safe = q.replace(/[%_,()]/g, " ");
    query = query.or(
      `name.ilike.%${safe}%,email.ilike.%${safe}%,title.ilike.%${safe}%,message.ilike.%${safe}%`
    );
  }

  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

/** Admin: change status and/or admin note of one review. */
export async function updateReview(id, { status, adminNote } = {}) {
  const patch = {};
  if (status !== undefined) patch.status = status;
  if (adminNote !== undefined) patch.admin_note = adminNote;
  if (Object.keys(patch).length === 0) return;

  const { error } = await supabase.from("reviews").update(patch).eq("id", id);
  if (error) throw error;
}

/** Admin: delete any review. */
export async function adminDeleteReview(id) {
  const { error } = await supabase.from("reviews").delete().eq("id", id);
  if (error) throw error;
}
