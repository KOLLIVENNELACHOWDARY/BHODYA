import { useState } from "react";

/**
 * 1–5 star rating.
 *   editable:  <StarRating value={n} onChange={setN} />
 *   read-only: <StarRating value={n} />
 */
export default function StarRating({ value = 0, onChange, size = "text-3xl" }) {
  const [hover, setHover] = useState(0);
  const active = hover || value;
  const editable = Boolean(onChange);

  return (
    <div
      className="flex items-center gap-1"
      onMouseLeave={() => setHover(0)}
      role={editable ? "radiogroup" : "img"}
      aria-label={`Rating: ${value} of 5 stars`}
    >
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          disabled={!editable}
          onMouseEnter={() => editable && setHover(n)}
          onClick={() => editable && onChange(n)}
          aria-label={`${n} star${n > 1 ? "s" : ""}`}
          className={`${size} leading-none transition ${
            n <= active ? "text-amber-400" : "text-slate-300"
          } ${editable ? "cursor-pointer hover:scale-110" : "cursor-default"}`}
        >
          ★
        </button>
      ))}
    </div>
  );
}
