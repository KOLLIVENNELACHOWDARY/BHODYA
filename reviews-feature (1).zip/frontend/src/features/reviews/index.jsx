import { useEffect, useState } from "react";
import {
  getMyReview,
  submitReview,
  updateMyReview,
  deleteMyReview,
} from "./api";
import StarRating from "./components/StarRating";

// Admin-side storage sheet — mount at /admin/reviews.
export { default as AdminReviewsSheet } from "./AdminReviewsSheet";

const MIN_MESSAGE = 10;

/**
 * `/reviews` — app-store-style review form:
 *   ⭐ 1–5 stars + review title + review text.
 * One review per user (edit / delete anytime).
 * ALL reviews are stored on the admin side — users only see their own.
 */
export default function ReviewsPage() {
  const [myReview, setMyReview] = useState(undefined); // undefined = loading
  const [editing, setEditing] = useState(false);
  const [rating, setRating] = useState(0);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    getMyReview()
      .then((r) => {
        setMyReview(r);
        if (r) startEditing(r);
      })
      .catch(() => setMyReview(null));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function startEditing(r) {
    setEditing(true);
    setRating(r?.rating ?? 0);
    setTitle(r?.title ?? "");
    setMessage(r?.message ?? "");
  }

  function resetForm() {
    setEditing(false);
    setRating(0);
    setTitle("");
    setMessage("");
  }

  const canSubmit =
    rating >= 1 && message.trim().length >= MIN_MESSAGE && !submitting;

  async function handleSubmit(e) {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    setError(null);
    try {
      if (myReview) {
        await updateMyReview(myReview.id, { rating, title, message });
      } else {
        await submitReview({ rating, title, message });
      }
      setMyReview(await getMyReview());
      resetForm();
      setDone(true);
    } catch (err) {
      setError(err?.message ?? "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!myReview) return;
    if (!window.confirm("Delete your review?")) return;
    try {
      await deleteMyReview(myReview.id);
      setMyReview(null);
      resetForm();
      setDone(false);
    } catch (err) {
      setError(err?.message ?? "Delete failed.");
    }
  }

  return (
    <div className="flex min-h-screen items-start justify-center bg-slate-50 px-6 py-12">
      <div className="w-full max-w-xl">
        {done && !editing ? (
          /* ── success state ─────────────────────────────── */
          <div className="rounded-2xl bg-white p-10 text-center shadow-sm ring-1 ring-slate-200">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-green-100 text-3xl">
              🌟
            </div>
            <h1 className="mt-5 text-xl font-semibold text-slate-900">
              Thanks for your review!
            </h1>
            <p className="mt-2 text-sm text-slate-500">
              It has been recorded and our team reads every review.
            </p>
            <div className="mt-6 flex justify-center gap-3">
              <button
                onClick={() => {
                  setDone(false);
                  startEditing(myReview);
                }}
                className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
              >
                Edit my review
              </button>
              <button
                onClick={() => {
                  setDone(false);
                  resetForm();
                }}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
              >
                Done
              </button>
            </div>
          </div>
        ) : editing || !myReview ? (
          /* ── form (new or edit) ────────────────────────── */
          <form
            onSubmit={handleSubmit}
            className="rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200"
          >
            <h1 className="text-2xl font-semibold text-slate-900">
              {myReview ? "Edit your review" : "Review the AI Learning Companion"}
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              How has the app helped your studies? Your review is stored on the
              admin side and helps us improve.
            </p>

            {/* rating */}
            <div className="mt-7">
              <label className="text-sm font-medium text-slate-700">
                Your rating
              </label>
              <div className="mt-2">
                <StarRating value={rating} onChange={setRating} />
              </div>
            </div>

            {/* title */}
            <div className="mt-6">
              <label
                htmlFor="review-title"
                className="text-sm font-medium text-slate-700"
              >
                Title <span className="text-slate-400">(optional)</span>
              </label>
              <input
                id="review-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Sum it up in a few words…"
                maxLength={120}
                className="mt-2 w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
              />
            </div>

            {/* message */}
            <div className="mt-6">
              <label
                htmlFor="review-message"
                className="text-sm font-medium text-slate-700"
              >
                Your review
              </label>
              <textarea
                id="review-message"
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="What do you like most? What should we improve?"
                className="mt-2 w-full rounded-xl border border-slate-300 px-3 py-2.5 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
              />
              <p className="mt-1 text-right text-xs text-slate-400">
                {message.trim().length} / 4000
              </p>
            </div>

            {/* error */}
            {error ? (
              <div className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
                {error}
              </div>
            ) : null}

            {/* submit */}
            <button
              type="submit"
              disabled={!canSubmit}
              className="mt-4 w-full rounded-xl bg-indigo-600 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {submitting
                ? "Saving…"
                : myReview
                  ? "Update my review"
                  : "Submit review"}
            </button>
            {myReview ? (
              <button
                type="button"
                onClick={() => {
                  resetForm();
                  setDone(true);
                }}
                className="mt-2 w-full rounded-xl border border-slate-300 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
            ) : null}
            <p className="mt-3 text-center text-xs text-slate-400">
              {rating >= 1 && message.trim().length >= MIN_MESSAGE
                ? "Ready to send 🚀"
                : "Add a rating and a few words to enable submit"}
            </p>
          </form>
        ) : (
          /* ── your existing review ──────────────────────── */
          <div className="rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-200">
            <h1 className="text-2xl font-semibold text-slate-900">
              Your review
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              Thanks for reviewing! You can edit or delete it anytime.
            </p>

            <div className="mt-6 rounded-2xl border border-slate-200 p-5">
              <div className="flex items-center justify-between">
                <StarRating value={myReview.rating} size="text-2xl" />
                <span
                  className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                    myReview.status === "approved"
                      ? "bg-green-100 text-green-700"
                      : myReview.status === "hidden"
                        ? "bg-slate-200 text-slate-500"
                        : "bg-amber-100 text-amber-700"
                  }`}
                >
                  {myReview.status}
                </span>
              </div>
              {myReview.title ? (
                <p className="mt-3 text-base font-semibold text-slate-900">
                  {myReview.title}
                </p>
              ) : null}
              <p className="mt-2 text-sm text-slate-600">{myReview.message}</p>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => startEditing(myReview)}
                className="flex-1 rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700"
              >
                ✏️ Edit review
              </button>
              <button
                onClick={handleDelete}
                className="rounded-xl border border-red-200 px-5 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50"
              >
                🗑 Delete
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
