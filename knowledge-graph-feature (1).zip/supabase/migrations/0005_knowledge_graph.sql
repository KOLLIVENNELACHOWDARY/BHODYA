-- Personal knowledge graph (FEATURE_MODULE_MAP #4).
-- Adds: knowledge_nodes + knowledge_edges + RLS.
--
-- NOTE: ARCHITECTURE.md says these tables may already exist in 0001_init.sql —
-- every statement is `if not exists`, so this is safe either way. If 0001 uses
-- different column names, keep 0001's schema and adjust the code instead.
--
-- Nodes & edges are created ONLY by the AI (backend routers/knowledge_graph.py,
-- service-role key) — extraction from documents, tutor chats and quiz activity.

create table if not exists public.knowledge_nodes (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references auth.users (id) on delete cascade,
  label       text not null,
  description text,
  topic       text default 'general',   -- used for node colours
  source      text default 'mixed',     -- document | chat | quiz | mixed
  created_at  timestamptz not null default now()
);

create table if not exists public.knowledge_edges (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users (id) on delete cascade,
  from_node  uuid not null references public.knowledge_nodes (id) on delete cascade,
  to_node    uuid not null references public.knowledge_nodes (id) on delete cascade,
  relation   text not null default 'related to',
  created_at timestamptz not null default now()
);

-- one node per label per user (case-insensitive), quick edge lookups
create unique index if not exists knowledge_nodes_user_label_idx
  on public.knowledge_nodes (user_id, lower(label));

create index if not exists knowledge_nodes_user_idx
  on public.knowledge_nodes (user_id);

create index if not exists knowledge_edges_from_idx
  on public.knowledge_edges (from_node);

create index if not exists knowledge_edges_to_idx
  on public.knowledge_edges (to_node);

create index if not exists knowledge_edges_user_idx
  on public.knowledge_edges (user_id);

-- ── RLS ─────────────────────────────────────────────────────────────────────
-- Users may read/delete their own graph. Inserts/updates happen through the
-- FastAPI backend (service-role key, bypasses RLS).
alter table public.knowledge_nodes enable row level security;
alter table public.knowledge_edges enable row level security;

create policy "knodes_select_own"
  on public.knowledge_nodes for select
  using (auth.uid() = user_id);

create policy "knodes_delete_own"
  on public.knowledge_nodes for delete
  using (auth.uid() = user_id);

create policy "kedges_select_own"
  on public.knowledge_edges for select
  using (auth.uid() = user_id);

create policy "kedges_delete_own"
  on public.knowledge_edges for delete
  using (auth.uid() = user_id);
