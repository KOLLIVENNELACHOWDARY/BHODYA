import { topicColor } from "./GraphCanvas";

/**
 * Side panel for the selected concept: description, topic, source,
 * and every connection ("edge") it has — click a neighbour to jump to it.
 */
export default function NodeDetails({ node, nodes, edges, onSelect, onDelete }) {
  if (!node) {
    return (
      <div className="flex h-full min-h-[300px] flex-col items-center justify-center rounded-2xl border border-slate-200 bg-white p-8 text-center">
        <div className="text-3xl">👆</div>
        <p className="mt-3 text-sm font-medium text-slate-700">Select a concept</p>
        <p className="mt-1 text-xs text-slate-400">
          Click any node on the canvas to see its description and connections.
          Drag nodes to rearrange · scroll to zoom.
        </p>
      </div>
    );
  }

  const byId = new Map(nodes.map((n) => [n.id, n]));
  const connections = edges
    .filter((e) => e.from_node === node.id || e.to_node === node.id)
    .map((e) => {
      const outgoing = e.from_node === node.id;
      const neighbour = byId.get(outgoing ? e.to_node : e.from_node);
      return { ...e, outgoing, neighbour };
    })
    .filter((c) => c.neighbour);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5">
      {/* header */}
      <div className="flex items-start gap-3">
        <span
          className="mt-1 h-4 w-4 flex-shrink-0 rounded-full"
          style={{ background: topicColor(node.topic) }}
        />
        <div className="min-w-0 flex-1">
          <h3 className="text-base font-semibold text-slate-900">{node.label}</h3>
          <p className="mt-0.5 text-xs text-slate-400">
            topic: {node.topic ?? "general"} · source: {node.source ?? "mixed"}
          </p>
        </div>
      </div>

      {node.description ? (
        <p className="mt-3 rounded-xl bg-slate-50 px-3 py-2.5 text-sm text-slate-600">
          {node.description}
        </p>
      ) : null}

      {/* connections */}
      <h4 className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-400">
        Connections ({connections.length})
      </h4>
      <ul className="mt-2 space-y-1.5">
        {connections.length === 0 ? (
          <li className="text-xs text-slate-400">No links yet.</li>
        ) : (
          connections.map((c) => (
            <li key={c.id ?? `${c.from_node}-${c.to_node}-${c.relation}`}>
              <button
                onClick={() => onSelect(c.neighbour.id)}
                className="flex w-full items-center gap-2 rounded-lg border border-slate-100 px-2.5 py-2 text-left text-xs transition hover:border-indigo-200 hover:bg-indigo-50"
              >
                <span className="text-slate-400">
                  {c.outgoing ? "→" : "←"}
                </span>
                <span className="text-slate-500">{c.relation}</span>
                <span className="font-semibold text-slate-800">
                  {c.neighbour.label}
                </span>
              </button>
            </li>
          ))
        )}
      </ul>

      {/* delete */}
      <button
        onClick={() => onDelete(node.id)}
        className="mt-5 w-full rounded-lg border border-red-200 px-3 py-2 text-xs font-medium text-red-600 transition hover:bg-red-50"
      >
        🗑 Remove this concept
      </button>
    </div>
  );
}
