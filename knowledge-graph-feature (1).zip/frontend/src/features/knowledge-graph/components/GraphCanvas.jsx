import { useEffect, useRef, useState } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// Interactive force-directed graph on plain SVG — no external libraries.
//  · drag nodes  · wheel zoom  · drag background to pan  · click to select
// ─────────────────────────────────────────────────────────────────────────────

const PALETTE = [
  "#6366f1", "#f59e0b", "#10b981", "#ef4444",
  "#8b5cf6", "#06b6d4", "#f43f5e", "#84cc16",
];

export function topicColor(topic = "general") {
  let h = 0;
  for (const ch of topic) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return PALETTE[h % PALETTE.length];
}

const REPULSION = 5200;
const SPRING = 0.02;
const REST_LENGTH = 130;
const GRAVITY = 0.012;
const DAMPING = 0.86;
const SETTLE = 0.06;

export default function GraphCanvas({ nodes, edges, selectedId, onSelect }) {
  const simRef = useRef({ nodes: [], edges: [] });
  const viewRef = useRef({ x: 0, y: 0, k: 1 });
  const dragRef = useRef(null);   // node drag
  const panRef = useRef(null);    // background pan
  const rafRef = useRef(null);
  const [, forceRender] = useState(0);
  const wrapRef = useRef(null);

  // (re)seed the simulation whenever the data changes — keep existing positions
  useEffect(() => {
    const prev = new Map(simRef.current.nodes.map((n) => [n.id, n]));
    const count = Math.max(1, nodes.length);
    const simNodes = nodes.map((n, i) => {
      const old = prev.get(n.id);
      if (old) return { ...old, label: n.label, topic: n.topic };
      const angle = (2 * Math.PI * i) / count;
      return {
        id: n.id,
        label: n.label,
        topic: n.topic ?? "general",
        x: 400 + 200 * Math.cos(angle) + Math.random() * 30,
        y: 280 + 170 * Math.sin(angle) + Math.random() * 30,
        vx: 0,
        vy: 0,
      };
    });
    simRef.current = { nodes: simNodes, edges };
    tickLoop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes, edges]);

  useEffect(() => () => cancelAnimationFrame(rafRef.current), []);

  function tickLoop() {
    cancelAnimationFrame(rafRef.current);
    const step = () => {
      const { nodes: sn, edges: se } = simRef.current;
      if (sn.length === 0) return;

      // pairwise repulsion (n is small, O(n²) is fine)
      for (let i = 0; i < sn.length; i++) {
        for (let j = i + 1; j < sn.length; j++) {
          const a = sn[i];
          const b = sn[j];
          let dx = a.x - b.x;
          let dy = a.y - b.y;
          let d2 = dx * dx + dy * dy;
          if (d2 < 1) {
            dx = Math.random() - 0.5;
            dy = Math.random() - 0.5;
            d2 = 1;
          }
          const f = REPULSION / d2;
          const d = Math.sqrt(d2);
          a.vx += (dx / d) * f;
          a.vy += (dy / d) * f;
          b.vx -= (dx / d) * f;
          b.vy -= (dy / d) * f;
        }
      }

      // springs along edges
      const byId = new Map(sn.map((n) => [n.id, n]));
      for (const e of se) {
        const a = byId.get(e.from_node);
        const b = byId.get(e.to_node);
        if (!a || !b) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.max(1, Math.sqrt(dx * dx + dy * dy));
        const f = (d - REST_LENGTH) * SPRING;
        a.vx += (dx / d) * f;
        a.vy += (dy / d) * f;
        b.vx -= (dx / d) * f;
        b.vy -= (dy / d) * f;
      }

      // gravity toward centre + integrate
      let maxSpeed = 0;
      for (const n of sn) {
        if (dragRef.current?.id === n.id) {
          n.vx = 0;
          n.vy = 0;
          continue;
        }
        n.vx += (400 - n.x) * GRAVITY;
        n.vy += (280 - n.y) * GRAVITY;
        n.vx *= DAMPING;
        n.vy *= DAMPING;
        n.x += n.vx;
        n.y += n.vy;
        maxSpeed = Math.max(maxSpeed, Math.abs(n.vx) + Math.abs(n.vy));
      }

      forceRender((v) => v + 1);
      if (maxSpeed > SETTLE || dragRef.current) {
        rafRef.current = requestAnimationFrame(step);
      }
    };
    rafRef.current = requestAnimationFrame(step);
  }

  // ── interactions ─────────────────────────────────────────────────────────
  function onNodePointerDown(e, id) {
    e.stopPropagation();
    dragRef.current = { id, moved: false };
    e.target.setPointerCapture?.(e.pointerId);
  }

  function onNodePointerMove(e) {
    if (!dragRef.current) return;
    const svg = wrapRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const { x: vx, y: vy, k } = viewRef.current;
    const x = (e.clientX - rect.left - vx) / k;
    const y = (e.clientY - rect.top - vy) / k;
    const node = simRef.current.nodes.find((n) => n.id === dragRef.current.id);
    if (node) {
      node.x = x;
      node.y = y;
      node.vx = 0;
      node.vy = 0;
    }
    dragRef.current.moved = true;
    tickLoop();
  }

  function onNodePointerUp(id) {
    const wasDrag = dragRef.current;
    dragRef.current = null;
    if (wasDrag && !wasDrag.moved) onSelect(id);
    tickLoop();
  }

  function onBackgroundPointerDown(e) {
    panRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      vx: viewRef.current.x,
      vy: viewRef.current.y,
    };
    e.target.setPointerCapture?.(e.pointerId);
  }

  function onPointerMove(e) {
    if (dragRef.current) return onNodePointerMove(e);
    if (!panRef.current) return;
    const { startX, startY, vx, vy } = panRef.current;
    viewRef.current.x = vx + (e.clientX - startX);
    viewRef.current.y = vy + (e.clientY - startY);
    forceRender((v) => v + 1);
  }

  function onPointerUp() {
    panRef.current = null;
  }

  function onWheel(e) {
    const view = viewRef.current;
    const factor = e.deltaY > 0 ? 0.92 : 1.08;
    const k = Math.min(3, Math.max(0.3, view.k * factor));
    // zoom around cursor
    const rect = wrapRef.current.getBoundingClientRect();
    const cx = e.clientX - rect.left;
    const cy = e.clientY - rect.top;
    view.x = cx - ((cx - view.x) / view.k) * k;
    view.y = cy - ((cy - view.y) / view.k) * k;
    view.k = k;
    forceRender((v) => v + 1);
  }

  // ── render ───────────────────────────────────────────────────────────────
  const { nodes: sn, edges: se } = simRef.current;
  const byId = new Map(sn.map((n) => [n.id, n]));
  const { x: vx, y: vy, k } = viewRef.current;

  if (sn.length === 0) {
    return (
      <div className="flex h-full min-h-[420px] items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white">
        <div className="text-center">
          <div className="text-4xl">🧠</div>
          <p className="mt-3 text-sm font-medium text-slate-700">
            Your knowledge graph is empty
          </p>
          <p className="mt-1 max-w-xs text-xs text-slate-400">
            Click <b>✨ Build my graph</b> — the AI reads your study material and
            maps the concepts automatically.
          </p>
        </div>
      </div>
    );
  }

  return (
    <svg
      ref={wrapRef}
      className="h-full min-h-[480px] w-full cursor-grab touch-none rounded-2xl border border-slate-200 bg-white active:cursor-grabbing"
      onPointerDown={onBackgroundPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onWheel={onWheel}
    >
      <g transform={`translate(${vx},${vy}) scale(${k})`}>
        {/* edges */}
        {se.map((e) => {
          const a = byId.get(e.from_node);
          const b = byId.get(e.to_node);
          if (!a || !b) return null;
          const mx = (a.x + b.x) / 2;
          const my = (a.y + b.y) / 2;
          return (
            <g key={e.id ?? `${e.from_node}-${e.to_node}`}>
              <line
                x1={a.x}
                y1={a.y}
                x2={b.x}
                y2={b.y}
                stroke="#c7d2fe"
                strokeWidth={selectedId === e.from_node || selectedId === e.to_node ? 2.5 : 1.5}
              />
              {k > 0.55 ? (
                <text
                  x={mx}
                  y={my - 5}
                  textAnchor="middle"
                  fontSize={9}
                  fill="#94a3b8"
                  style={{ pointerEvents: "none" }}
                >
                  {e.relation}
                </text>
              ) : null}
            </g>
          );
        })}

        {/* nodes */}
        {sn.map((n) => {
          const selected = n.id === selectedId;
          return (
            <g
              key={n.id}
              transform={`translate(${n.x},${n.y})`}
              onPointerDown={(e) => onNodePointerDown(e, n.id)}
              onPointerUp={() => onNodePointerUp(n.id)}
              style={{ cursor: "pointer" }}
            >
              <circle
                r={selected ? 26 : 21}
                fill={topicColor(n.topic)}
                stroke={selected ? "#0f172a" : "#fff"}
                strokeWidth={selected ? 3 : 2}
              />
              <text
                y={4}
                textAnchor="middle"
                fontSize={10}
                fontWeight={700}
                fill="#fff"
                style={{ pointerEvents: "none" }}
              >
                {n.label.length > 3 ? n.label.slice(0, 3) : n.label}
              </text>
              <text
                y={38}
                textAnchor="middle"
                fontSize={11}
                fontWeight={600}
                fill="#334155"
                style={{ pointerEvents: "none" }}
              >
                {n.label}
              </text>
            </g>
          );
        })}
      </g>
    </svg>
  );
}
