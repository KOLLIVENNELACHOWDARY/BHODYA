# Personal Knowledge Graph — AI-mapped concepts from your studies

Implements **FEATURE_MODULE_MAP #4 (Personal knowledge graph)**. Route: `/knowledge-graph`.

The graph is **AI-only**: users never type concepts. The LLM reads study
material (documents, tutor chats, quiz activity), extracts key concepts and
the relationships between them, and stores them in `knowledge_nodes` /
`knowledge_edges`. The result is an **interactive, draggable canvas**.

## What it does

| Part | How |
|---|---|
| ✨ Auto-extract | LLM pulls concepts + relations as JSON from study text (Groq → Gemini fallback) |
| 🔄 Auto + manual triggers | Other features call `extractConcepts(text, source)` after chats/ingests **and** a "✨ Build my graph" button scans everything on demand |
| 🧠 Interactive canvas | Custom force-directed SVG graph — drag nodes, scroll to zoom, pan, click to select (no new npm libraries) |
| 📋 Details panel | Click a concept → description, topic colour, source, all connections (click to jump) |
| 🧹 Tidy | "Remove this concept" deletes noise nodes (edges cascade) |

## Files

| File | Purpose |
|---|---|
| `index.jsx` | `/knowledge-graph` page: header + build button + canvas + details |
| `api.js` | Supabase reads + FastAPI calls (`extractConcepts`, `buildGraph`) |
| `components/GraphCanvas.jsx` | Force-directed SVG canvas (drag / zoom / pan / select) |
| `components/NodeDetails.jsx` | Selected-concept panel with connections |
| `backend/app/routers/knowledge_graph.py` | **FastAPI router** — `/extract` + `/build` |
| `supabase/migrations/0005_knowledge_graph.sql` | `knowledge_nodes` + `knowledge_edges` + RLS |

## Setup

**1. Migration** — run `supabase/migrations/0005_knowledge_graph.sql`
(safe if `0001_init.sql` already created the tables — all `if not exists`).

**2. Backend** — copy `backend/app/routers/knowledge_graph.py` into your FastAPI app:

```python
# backend/app/main.py
from app.routers import knowledge_graph
app.include_router(knowledge_graph.router)
```

Env vars (same `.env` as the RAG feature):

```
SUPABASE_URL=...
SUPABASE_SERVICE_ROLE_KEY=...
GROQ_API_KEY=...        # chat (extraction)
GEMINI_API_KEY=...      # fallback chat
```

**3. Frontend** — one route in `App.jsx`:

```jsx
import KnowledgeGraphPage from "./features/knowledge-graph";
// ...
<Route path="/knowledge-graph" element={<KnowledgeGraphPage />} />
```

## API contract (for API_CONTRACTS.md)

**Endpoint:** `POST /api/knowledge-graph/extract`

```json
{ "content": "…study text…", "source": "chat", "title": "Tutor chat: photosynthesis", "user_id": "uuid" }
```

_Response:_ `{ "status": "ok", "added_nodes": 3, "added_edges": 4, "concepts_found": 5 }`

**Endpoint:** `POST /api/knowledge-graph/build`

```json
{ "user_id": "uuid" }
```

_Response:_ `{ "status": "ok", "added_nodes": 7, "added_edges": 9, "sources_scanned": 6 }`

**Notes:** send `Authorization: Bearer <supabase access token>` plus the
signed-in `user_id`. `extract` handles one text; `build` scans the latest
documents → document chunks, `quiz_questions`, and `room_messages`. Concepts
are deduplicated case-insensitively per user; duplicate edges are skipped.

## Wiring the auto triggers (one-liners in other features)

The graph stays fresh automatically when related features call extraction —
add these tiny calls where you already have events:

```jsx
// in features/file-upload-rag — after a document reaches status 'ready':
import { extractConcepts } from "../knowledge-graph/api";
extractConcepts(documentText, "document", file.name).catch(() => {});

// in features/tutor-chat — after an assistant reply:
extractConcepts(chatTranscript, "chat", "Tutor chat").catch(() => {});
```

Both are fire-and-forget — they can never break the feature that calls them.

## How the AI extraction works

```
study text (≤ 6000 chars per call)
  → LLM prompt: "return ONLY JSON: concepts[] + relations[]"
  → tolerant JSON parse (strips code fences / prose)
  → merge:
       knowledge_nodes  upsert by lower(label)  (label, description, topic, source)
       knowledge_edges  dedupe (from, to, relation)
  → frontend reads nodes+edges straight from Supabase (RLS: own rows)
```

Node colours come from `topic` (hash → palette) — the legend shows your top
topics with counts.

## Assumptions / notes

- Tables `knowledge_nodes` / `knowledge_edges` are assumed from
  `0001_init.sql`; the migration uses `if not exists`, so if 0001 already
  made them (with different columns), adjust `api.js` + the router instead.
- `build` reads `document_chunks` (from the RAG feature), `quiz_questions`
  and `room_messages` — fields are read defensively (`.get()`), so minor
  schema differences are tolerated.
- Extraction temperature is 0.1 for stable graphs; 3–8 concepts per call.
- The canvas keeps positions when nodes are added (no layout jump).
- Graph reads/deletes go direct to Supabase; only AI calls need FastAPI —
  exactly the split in ARCHITECTURE.md.
