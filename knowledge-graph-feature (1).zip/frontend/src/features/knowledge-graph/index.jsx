import { useCallback, useEffect, useMemo, useState } from "react";
import { getGraph, deleteNode, buildGraph } from "./api";
import GraphCanvas, { topicColor } from "./components/GraphCanvas";
import NodeDetails from "./components/NodeDetails";

/**
 * `/knowledge-graph` — personal, AI-built map of what you know.
 *
 *  · Interactive canvas: drag nodes, zoom, click for details  (GraphCanvas)
 *  · ✨ Build my graph: AI scans documents + quizzes + chats   (buildGraph)
 *  · Everything is auto-extracted — no manual node typing
 */
export default function KnowledgeGraphPage() {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [building, setBuilding] = useState(false);
  const [error, setError] = useState(null);
  const [buildResult, setBuildResult] = useState(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const g = await getGraph();
      setNodes(g.nodes);
      setEdges(g.edges);
    } catch (err) {
      setError(err?.message ?? "Failed to load the graph.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleBuild() {
    setBuilding(true);
    setError(null);
    setBuildResult(null);
    try {
      const res = await buildGraph();
      setBuildResult(res);
      await load();
    } catch (err) {
      setError(err?.response?.data?.detail ?? err?.message ?? "Build failed.");
    } finally {
      setBuilding(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm("Remove this concept and its links?")) return;
    try {
      await deleteNode(id);
      if (selectedId === id) setSelectedId(null);
      await load();
    } catch (err) {
      setError(err?.message ?? "Delete failed.");
    }
  }

  const selected = useMemo(
    () => nodes.find((n) => n.id === selectedId) ?? null,
    [nodes, selectedId]
  );

  const topics = useMemo(() => {
    const counts = new Map();
    for (const n of nodes) {
      const t = n.topic ?? "general";
      counts.set(t, (counts.get(t) ?? 0) + 1);
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [nodes]);

  return (
    <div className="min-h-screen bg-slate-50 px-6 py-8">
      <div className="mx-auto max-w-7xl">
        {/* header */}
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900">
              Your knowledge graph
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              Every concept the AI has found in your study material — and how it
              all connects. {nodes.length} concepts · {edges.length} links
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={load}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-50"
            >
              Refresh
            </button>
            <button
              onClick={handleBuild}
              disabled={building}
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:opacity-50"
            >
              {building ? "✨ Building…" : "✨ Build my graph"}
            </button>
          </div>
        </div>

        {/* build result / errors */}
        {buildResult ? (
          <div className="mt-4 rounded-xl border border-green-200 bg-green-50 px-4 py-2.5 text-sm text-green-800">
            ✅ Scanned {buildResult.sources_scanned} source
            {buildResult.sources_scanned === 1 ? "" : "s"} — added{" "}
            <b>{buildResult.added_nodes}</b> concept
            {buildResult.added_nodes === 1 ? "" : "s"} and{" "}
            <b>{buildResult.added_edges}</b> link
            {buildResult.added_edges === 1 ? "" : "s"}.
          </div>
        ) : null}
        {error ? (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-2.5 text-sm text-red-700">
            {error}
          </div>
        ) : null}

        {/* legend */}
        {topics.length > 0 ? (
          <div className="mt-4 flex flex-wrap items-center gap-3">
            {topics.map(([topic, count]) => (
              <span
                key={topic}
                className="flex items-center gap-1.5 rounded-full bg-white px-3 py-1 text-xs text-slate-600 ring-1 ring-slate-200"
              >
                <span
                  className="h-2.5 w-2.5 rounded-full"
                  style={{ background: topicColor(topic) }}
                />
                {topic} <b>({count})</b>
              </span>
            ))}
          </div>
        ) : null}

        {/* graph + details */}
        <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-[1fr_320px]">
          <div className="h-[600px]">
            {loading ? (
              <div className="flex h-full min-h-[420px] items-center justify-center rounded-2xl border border-slate-200 bg-white">
                <p className="animate-pulse text-sm text-slate-400">
                  Loading your graph…
                </p>
              </div>
            ) : (
              <GraphCanvas
                nodes={nodes}
                edges={edges}
                selectedId={selectedId}
                onSelect={setSelectedId}
              />
            )}
          </div>
          <NodeDetails
            node={selected}
            nodes={nodes}
            edges={edges}
            onSelect={setSelectedId}
            onDelete={handleDelete}
          />
        </div>
      </div>
    </div>
  );
}
