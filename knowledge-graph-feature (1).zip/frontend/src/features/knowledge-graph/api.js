import { supabase } from "../../supabaseClient";
import { backend } from "../../backendClient";

// ─────────────────────────────────────────────────────────────────────────────
// Personal knowledge graph (Supabase reads + FastAPI routers/knowledge_graph.py).
//
// The graph is AI-only: no manual node creation. Concepts are extracted by the
// backend (extract / build) and stored in knowledge_nodes + knowledge_edges.
// The frontend reads them directly (RLS: own rows) and may delete nodes.
// ─────────────────────────────────────────────────────────────────────────────

async function currentUserId() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user?.id ?? null;
}

async function authHeaders() {
  const {
    data: { session },
  } = await supabase.auth.getSession();
  return session?.access_token
    ? { Authorization: `Bearer ${session.access_token}` }
    : {};
}

/** Fetch the whole graph for the signed-in user. */
export async function getGraph() {
  const [nodesRes, edgesRes] = await Promise.all([
    supabase
      .from("knowledge_nodes")
      .select("id, label, description, topic, source, created_at")
      .order("created_at", { ascending: false })
      .limit(300),
    supabase
      .from("knowledge_edges")
      .select("id, from_node, to_node, relation")
      .limit(900),
  ]);
  if (nodesRes.error) throw nodesRes.error;
  if (edgesRes.error) throw edgesRes.error;

  const nodes = nodesRes.data ?? [];
  const ids = new Set(nodes.map((n) => n.id));
  // drop edges that point at deleted nodes
  const edges = (edgesRes.data ?? []).filter(
    (e) => ids.has(e.from_node) && ids.has(e.to_node)
  );
  return { nodes, edges };
}

/**
 * Delete one concept (its edges are removed by the DB cascade).
 * Useful for tidying auto-extracted noise.
 */
export async function deleteNode(nodeId) {
  const { error } = await supabase.from("knowledge_nodes").delete().eq("id", nodeId);
  if (error) throw error;
}

// ── AI extraction (FastAPI) ─────────────────────────────────────────────────

/**
 * Extract concepts from ONE piece of study text and merge them into the graph.
 * Auto-trigger: call this after a tutor chat finishes or a document ingests.
 *
 *   extractConcepts(chatText, "chat", "Tutor chat: photosynthesis");
 */
export async function extractConcepts(content, source = "document", title = null) {
  const userId = await currentUserId();
  if (!userId) throw new Error("Please sign in first.");
  const { data, error } = await backend.post(
    "/api/knowledge-graph/extract",
    { content, source, title, user_id: userId },
    { headers: await authHeaders() }
  );
  if (error) throw error;
  return data;
}

/**
 * Scan recent study material (documents + quizzes + chats) and extract
 * everything missing — powers the "✨ Build my graph" button.
 * Returns { added_nodes, added_edges, sources_scanned }.
 */
export async function buildGraph() {
  const userId = await currentUserId();
  if (!userId) throw new Error("Please sign in first.");
  const { data, error } = await backend.post(
    "/api/knowledge-graph/build",
    { user_id: userId },
    { headers: await authHeaders() }
  );
  if (error) throw error;
  return data;
}
