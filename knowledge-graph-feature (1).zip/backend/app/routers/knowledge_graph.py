"""
Knowledge-graph router — personal knowledge graph (FEATURE_MODULE_MAP #4).

Endpoints
---------
POST /api/knowledge-graph/extract   { content, source, title?, user_id? }
POST /api/knowledge-graph/build     { user_id? }
GET  /api/knowledge-graph/health

How it works
------------
The graph is AI-only: users never type concepts. Study text (document chunks,
tutor chats, quiz activity) is sent to an LLM which extracts key concepts and
the relationships between them as JSON. The merge step upserts:

* knowledge_nodes  — one row per concept label per user (case-insensitive)
* knowledge_edges  — one row per (from → to, relation)

"extract" handles one piece of text (call it after a tutor chat or a doc
ingest — the auto trigger). "build" scans the user's recent study material
in batches and extracts from everything it finds (the manual button).

Frontend reads the graph directly from Supabase (RLS = own rows only).

Environment (.env in backend/)
------------------------------
SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
GROQ_API_KEY and/or GEMINI_API_KEY   (Groq first, Gemini fallback)
"""

from __future__ import annotations

import json
import os
import re
from typing import Any, Optional

import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from supabase import Client, createClient

router = APIRouter(prefix="/api/knowledge-graph", tags=["knowledge-graph"])

# ── configuration ───────────────────────────────────────────────────────────
SUPABASE_URL = os.environ.get("SUPABASE_URL", "")
SUPABASE_SERVICE_ROLE_KEY = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")

GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.1-8b-instant")
GEMINI_TEXT_MODEL = os.environ.get("GEMINI_TEXT_MODEL", "gemini-1.5-flash")

MAX_SOURCE_CHARS = 6000     # per extraction call
BUILD_MAX_DOCS = 4          # docs scanned per "build"
BUILD_MAX_QUIZ = 8          # quiz items per build
BUILD_MAX_CHAT = 8          # chat messages per build

_http = httpx.AsyncClient(timeout=90)
_db: Optional[Client] = None


def db() -> Client:
    global _db
    if _db is None:
        if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
            raise HTTPException(
                500, "SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured"
            )
        _db = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
    return _db


# ── request models ──────────────────────────────────────────────────────────
class ExtractRequest(BaseModel):
    content: str = Field(min_length=1, max_length=20000)
    source: str = Field(default="document")  # document | chat | quiz
    title: Optional[str] = None
    user_id: Optional[str] = None            # fallback when no JWT is sent


class BuildRequest(BaseModel):
    user_id: Optional[str] = None


# ── helpers ─────────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You extract a personal knowledge graph from study text.
Return ONLY valid JSON (no prose, no code fences) in this exact shape:
{
  "concepts": [
    {"label": "short concept name", "description": "one clear sentence", "topic": "subject-area"}
  ],
  "relations": [
    {"from": "concept label", "to": "concept label", "relation": "short verb phrase"}
  ]
}
Rules:
- 3 to 8 distinct concepts, each label under 4 words.
- 1 to 8 relations, `from`/`to` must match concept labels exactly.
- `relation` is a short verb phrase like "requires", "is part of", "causes", "contrasts with".
- topic is 1-2 lowercase words (e.g. "biology", "algebra", "history").
"""


def parse_llm_json(text: str) -> dict:
    """Tolerate code fences / leading prose around the JSON object."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.MULTILINE).strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise HTTPException(502, "LLM did not return JSON")
    try:
        data = json.loads(text[start : end + 1])
    except json.JSONDecodeError as exc:
        raise HTTPException(502, f"Could not parse LLM JSON: {exc}") from exc
    data.setdefault("concepts", [])
    data.setdefault("relations", [])
    return data


async def llm_extract(content: str, source: str, title: Optional[str]) -> dict:
    """Groq first, Gemini fallback. Returns parsed JSON."""
    user_msg = f"Source type: {source}\n"
    if title:
        user_msg += f"Title: {title}\n"
    user_msg += f"\nStudy text:\n{content[:MAX_SOURCE_CHARS]}"

    if GROQ_API_KEY:
        r = await _http.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
            json={
                "model": GROQ_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "temperature": 0.1,
            },
        )
        if r.status_code == 200:
            return parse_llm_json(r.json()["choices"][0]["message"]["content"])

    if GEMINI_API_KEY:
        r = await _http.post(
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{GEMINI_TEXT_MODEL}:generateContent",
            params={"key": GEMINI_API_KEY},
            json={
                "systemInstruction": {"parts": [{"text": SYSTEM_PROMPT}]},
                "contents": [{"role": "user", "parts": [{"text": user_msg}]}],
                "generationConfig": {"temperature": 0.1},
            },
        )
        if r.status_code == 200:
            return parse_llm_json(r.json()["candidates"][0]["content"]["parts"][0]["text"])

    raise HTTPException(502, "No LLM available — set GROQ_API_KEY or GEMINI_API_KEY")


def resolve_user_id(payload_user_id: Optional[str]) -> str:
    """Service client has no session — trust the JWT check done at the edge,
    or the user_id the (authenticated) frontend sends."""
    user_id = payload_user_id
    if not user_id:
        raise HTTPException(401, "user_id is required (send it from the signed-in frontend)")
    return user_id


def merge_graph(user_id: str, data: dict, source: str) -> dict:
    """Upsert concepts + relations into knowledge_nodes / knowledge_edges."""
    supabase = db()
    label_to_id: dict[str, str] = {}

    def get_or_none(rows: list[dict]) -> Optional[dict]:
        return rows[0] if rows else None

    # ── nodes ───────────────────────────────────────────────────────────────
    added_nodes = 0
    for concept in data.get("concepts", []):
        label = str(concept.get("label", "")).strip()
        if not label:
            continue
        existing = get_or_none(
            supabase.table("knowledge_nodes")
            .select("id")
            .eq("user_id", user_id)
            .ilike("label", label)
            .limit(1)
            .execute()
            .data
            or []
        )
        if existing:
            label_to_id[label.lower()] = existing["id"]
            continue
        res = (
            supabase.table("knowledge_nodes")
            .insert(
                {
                    "user_id": user_id,
                    "label": label,
                    "description": str(concept.get("description", ""))[:500],
                    "topic": str(concept.get("topic", "general"))[:60].lower(),
                    "source": source,
                }
            )
            .execute()
        )
        row = (res.data or [{}])[0]
        if row.get("id"):
            label_to_id[label.lower()] = row["id"]
            added_nodes += 1

    # ── edges ───────────────────────────────────────────────────────────────
    added_edges = 0
    for rel in data.get("relations", []):
        frm = str(rel.get("from", "")).strip().lower()
        to = str(rel.get("to", "")).strip().lower()
        relation = str(rel.get("relation", "related to")).strip()[:80] or "related to"
        frm_id, to_id = label_to_id.get(frm), label_to_id.get(to)
        if not frm_id or not to_id or frm_id == to_id:
            continue
        duplicate = (
            supabase.table("knowledge_edges")
            .select("id")
            .eq("user_id", user_id)
            .eq("from_node", frm_id)
            .eq("to_node", to_id)
            .ilike("relation", relation)
            .limit(1)
            .execute()
            .data
            or []
        )
        if duplicate:
            continue
        supabase.table("knowledge_edges").insert(
            {
                "user_id": user_id,
                "from_node": frm_id,
                "to_node": to_id,
                "relation": relation,
            }
        ).execute()
        added_edges += 1

    return {"added_nodes": added_nodes, "added_edges": added_edges}


# ── endpoints ───────────────────────────────────────────────────────────────
@router.post("/extract")
async def extract(req: ExtractRequest) -> dict:
    """Extract concepts + relations from one piece of study text and merge."""
    user_id = resolve_user_id(req.user_id)
    data = await llm_extract(req.content, req.source, req.title)
    stats = merge_graph(user_id, data, req.source)
    return {"status": "ok", **stats, "concepts_found": len(data.get("concepts", []))}


@router.post("/build")
async def build(req: BuildRequest) -> dict:
    """Scan recent study material and rebuild missing knowledge.

    Sources (newest first, per user):
      * document chunks  (from the file-upload + RAG feature)
      * quiz questions   (from the quizzes feature)
      * room messages    (collab rooms / chat)
    """
    user_id = resolve_user_id(req.user_id)
    supabase = db()
    totals = {"added_nodes": 0, "added_edges": 0, "sources_scanned": 0}

    def bump(stats: dict) -> None:
        totals["added_nodes"] += stats["added_nodes"]
        totals["added_edges"] += stats["added_edges"]
        totals["sources_scanned"] += 1

    # 1) recent document chunks — grouped per document
    docs = (
        supabase.table("uploaded_documents")
        .select("id, name, kind")
        .eq("user_id", user_id)
        .eq("status", "ready")
        .order("created_at", desc=True)
        .limit(BUILD_MAX_DOCS)
        .execute()
        .data
        or []
    )
    for doc in docs:
        if doc.get("kind") == "image":
            continue
        chunks = (
            supabase.table("document_chunks")
            .select("content")
            .eq("document_id", doc["id"])
            .order("chunk_index")
            .limit(4)
            .execute()
            .data
            or []
        )
        text = "\n".join(c["content"] for c in chunks)
        if len(text.strip()) < 80:
            continue
        data = await llm_extract(text, "document", doc.get("name"))
        bump(merge_graph(user_id, data, "document"))

    # 2) quiz questions
    quizzes = (
        supabase.table("quiz_questions")
        .select("*")
        .eq("user_id", user_id)
        .order("created_at", desc=True)
        .limit(BUILD_MAX_QUIZ)
        .execute()
        .data
        or []
    )
    if quizzes:
        text = "\n".join(
            f"- {q.get('question', q.get('text', ''))}" for q in quizzes if q
        )
        if len(text.strip()) >= 40:
            data = await llm_extract(text, "quiz", None)
            bump(merge_graph(user_id, data, "quiz"))

    # 3) chat / room messages
    messages = (
        supabase.table("room_messages")
        .select("*")
        .eq("user_id", user_id)
        .order("created_at", desc=True)
        .limit(BUILD_MAX_CHAT)
        .execute()
        .data
        or []
    )
    if messages:
        text = "\n".join(
            f"- {m.get('content', m.get('message', m.get('body', '')))}"
            for m in messages
            if m
        )
        if len(text.strip()) >= 40:
            data = await llm_extract(text, "chat", None)
            bump(merge_graph(user_id, data, "chat"))

    return {"status": "ok", **totals}


@router.get("/health")
async def health() -> dict:
    return {"status": "ok", "feature": "knowledge-graph"}
