# API Contracts

Each feature owner adds a section here describing their endpoint(s) so the
frontend side knows exactly what to send/expect. Copy this template:

## Feature: <name>

**Endpoint:** `POST /api/<router>/<action>`

**Request body:**
```json
{
  "example_field": "value"
}
```

**Response:**
```json
{
  "example_field": "value"
}
```

**Notes:** any auth requirements, rate limits, or edge cases.

---
