-- 0002 — Login / Signup feature (features/auth)
-- Extends the starter schema WITHOUT editing 0001 (per its header rule).
-- Run once in the Supabase SQL editor, after 0001.
--
-- What this adds:
--   1. Signup columns on profiles (username, age, education, preferences...)
--   2. usernames(username -> email) lookup table for username login
--   3. handle_new_user() trigger: creates the profile row + username mapping
--      atomically when Supabase Auth creates the account
--   4. RLS: users can only see/modify their own profile row
--
-- Passwords are NEVER stored here — Supabase Auth (auth.users) owns them.

-- 1. Signup columns on profiles -------------------------------------------
alter table profiles
  add column if not exists username             text,
  add column if not exists age                  int check (age between 5 and 100),
  add column if not exists education_level      text check (education_level in ('high_school','undergraduate','postgraduate','other')),
  add column if not exists class_grade          text,   -- high school: class/grade
  add column if not exists course               text,   -- UG/PG: degree/course
  add column if not exists branch               text,   -- UG: branch/department
  add column if not exists specialization       text,   -- PG: specialization
  add column if not exists current_year         text,   -- UG/PG: 1st/2nd/3rd/...
  add column if not exists subjects             jsonb default '[]'::jsonb,  -- education subjects
  add column if not exists content_preferences  jsonb default '[]'::jsonb,
  add column if not exists interest_subjects    jsonb default '[]'::jsonb,  -- learning-pref subjects
  add column if not exists learning_goals       jsonb default '[]'::jsonb,
  add column if not exists preferred_difficulty text check (preferred_difficulty in ('beginner','intermediate','advanced')),
  add column if not exists preferred_language   text check (preferred_language in ('english','telugu','hindi','other')),
  add column if not exists onboarding_completed boolean default false,
  add column if not exists updated_at           timestamptz default now();

-- Usernames are normalized to lowercase by the client, so a plain
-- unique index gives us uniqueness. NULLs (pre-existing rows) are allowed.
create unique index if not exists profiles_username_key on profiles (username);

create or replace function set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists profiles_set_updated_at on profiles;
create trigger profiles_set_updated_at
  before update on profiles
  for each row execute function set_updated_at();

-- 2. Username -> email mapping --------------------------------------------
-- Supabase Auth signs in with email only, and the frontend anon key cannot
-- read auth.users. This tiny table is the only extra data exposed, and it
-- is what makes "login with username" possible without any third-party
-- service or a service-role key in the browser. Rows are written by the
-- trigger below (never by clients), and only username<->email is readable.
create table if not exists usernames (
  username   text primary key,
  email      text not null,
  user_id    uuid unique references profiles(id) on delete cascade,
  created_at timestamptz default now()
);

-- 3. Auto-create profile + username mapping on signup ----------------------
-- Runs inside the auth.users insert transaction: if the username is already
-- taken, the whole signup fails atomically (no orphaned auth user).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  meta jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  uname text := nullif(lower(trim(meta->>'username')), '');
begin
  insert into public.profiles (
    id, username, display_name, age, age_band,
    education_level, class_grade, course, branch, specialization, current_year,
    subjects, content_preferences, interest_subjects, learning_goals,
    preferred_difficulty, preferred_language, onboarding_completed
  )
  values (
    new.id,
    uname,
    coalesce(nullif(meta->>'display_name', ''), uname),
    nullif(meta->>'age', '')::int,
    coalesce(nullif(meta->>'age_band', ''), 'teen'),
    nullif(meta->>'education_level', ''),
    nullif(meta->>'class_grade', ''),
    nullif(meta->>'course', ''),
    nullif(meta->>'branch', ''),
    nullif(meta->>'specialization', ''),
    nullif(meta->>'current_year', ''),
    coalesce(meta->'subjects',            '[]'::jsonb),
    coalesce(meta->'content_preferences', '[]'::jsonb),
    coalesce(meta->'interest_subjects',   '[]'::jsonb),
    coalesce(meta->'learning_goals',      '[]'::jsonb),
    nullif(meta->>'preferred_difficulty', ''),
    nullif(meta->>'preferred_language', ''),
    coalesce((meta->>'onboarding_completed')::boolean, false)
  )
  on conflict (id) do nothing;

  if uname is not null then
    insert into public.usernames (username, email, user_id)
    values (uname, new.email, new.id);
  end if;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 4. Row Level Security ----------------------------------------------------
-- profiles: own row only. (RLS was not enabled in 0001; enabling it here is
-- what the auth feature requires. Other features read the signed-in user's
-- own rows, so their access is unaffected.)
alter table profiles enable row level security;

drop policy if exists "profiles_select_own" on profiles;
create policy "profiles_select_own" on profiles
  for select using (auth.uid() = id);

drop policy if exists "profiles_insert_own" on profiles;
create policy "profiles_insert_own" on profiles
  for insert with check (auth.uid() = id);

drop policy if exists "profiles_update_own" on profiles;
create policy "profiles_update_own" on profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- usernames: readable by everyone (needed for the pre-login username->email
-- lookup and the availability check); writes happen only via the
-- security-definer trigger above, so clients get no write policies.
alter table usernames enable row level security;

drop policy if exists "usernames_select_all" on usernames;
create policy "usernames_select_all" on usernames
  for select using (true);
