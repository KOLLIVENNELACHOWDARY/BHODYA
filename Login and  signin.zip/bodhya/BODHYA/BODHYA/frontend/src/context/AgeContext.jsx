import { createContext, useContext, useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";

// Drives the "change dashboard according to age" feature — components
// read this instead of each doing their own age check.
const AgeContext = createContext(null);

// The ONE age -> age-band rule for the whole app (per ARCHITECTURE.md, age
// logic lives here). Signup uses it to fill profiles.age_band, so the same
// child/teen/adult bands drive the dashboard and signup consistently.
export function getAgeBand(age) {
  const n = Number(age);
  if (!Number.isFinite(n)) return "teen";
  if (n < 13) return "child";
  if (n <= 17) return "teen";
  return "adult";
}

export function AgeProvider({ children }) {
  const [ageBand, setAgeBand] = useState("teen"); // "child" | "teen" | "adult"
  const { profile } = useAuth();

  // Follow the signed-in user's stored band (profiles.age_band).
  useEffect(() => {
    if (profile?.age_band) setAgeBand(profile.age_band);
  }, [profile]);

  return (
    <AgeContext.Provider value={{ ageBand, setAgeBand }}>
      {children}
    </AgeContext.Provider>
  );
}

export const useAgeBand = () => useContext(AgeContext);
