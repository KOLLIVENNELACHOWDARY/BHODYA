// Supabase Auth + database calls for the Login / Signup feature.
// Uses the project's existing supabase client (src/lib/supabaseClient.js)
// and Supabase Auth only — no FastAPI, no third-party services.
import { supabase } from "../../lib/supabaseClient";
import { normalizeUsername, buildProfilePayload } from "./validation";
import { getAgeBand } from "../../context/AgeContext.jsx";

/**
 * Check username availability against the public `usernames` mapping table.
 * Used for instant feedback while the user types; final uniqueness is
 * enforced atomically by the DB (unique indexes + signup trigger).
 */
export async function checkUsernameAvailable(username) {
  const uname = normalizeUsername(username);
  const { data, error } = await supabase
    .from("usernames")
    .select("username")
    .eq("username", uname)
    .maybeSingle();
  if (error) return { available: false, error: error.message };
  return { available: !data, error: null };
}

/**
 * Sign up: creates the Supabase Auth account. The collected signup
 * information travels as user_metadata; the handle_new_user() trigger
 * (0002 migration) copies it into `profiles` + `usernames` atomically.
 * The password goes ONLY to Supabase Auth — never to the database.
 */
export async function signUp({ email, password, basic, education, preferences }) {
  const payload = buildProfilePayload({
    basic,
    education,
    preferences,
    ageBand: getAgeBand(Number(basic.age)),
  });

  const { data, error } = await supabase.auth.signUp({
    email: String(email).trim().toLowerCase(),
    password,
    options: { data: payload },
  });

  if (error) return { ok: false, needsEmailConfirmation: false, error: friendlyAuthError(error) };

  // If the Supabase project requires email confirmation, there is no
  // session yet — the user must confirm, then log in.
  const needsEmailConfirmation = !data.session;
  return { ok: true, needsEmailConfirmation, error: null };
}

/** Email + password login via Supabase Auth. */
export async function loginWithEmail(email, password) {
  const { error } = await supabase.auth.signInWithPassword({
    email: String(email).trim().toLowerCase(),
    password,
  });
  return error ? { ok: false, error: friendlyAuthError(error) } : { ok: true, error: null };
}

/**
 * Username + password login — still Supabase Auth.
 * Supabase signs in with email only, so we resolve the username to the
 * account's email via the `usernames` table (written by the DB trigger at
 * signup), then call the exact same signInWithPassword. No passwords are
 * stored or compared outside Supabase Auth, and no other service is used.
 */
export async function loginWithUsername(username, password) {
  const uname = normalizeUsername(username);
  const { data, error } = await supabase
    .from("usernames")
    .select("email")
    .eq("username", uname)
    .maybeSingle();

  if (error) return { ok: false, error: "Something went wrong. Please try again." };
  // Same generic message as a wrong password — don't reveal which
  // usernames exist.
  if (!data) return { ok: false, error: "Invalid username or password." };

  return loginWithEmail(data.email, password);
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

/** Map raw Supabase Auth errors to clear, student-friendly messages. */
export function friendlyAuthError(error) {
  const msg = String(error?.message ?? "").toLowerCase();
  if (msg.includes("invalid login credentials") || msg.includes("invalid credentials"))
    return "Invalid email or password.";
  if (msg.includes("email not confirmed"))
    return "Please confirm your email address first (check your inbox), then log in.";
  if (msg.includes("already registered") || msg.includes("already been registered"))
    return "An account with this email already exists. Try logging in.";
  if (msg.includes("duplicate key") || msg.includes("username"))
    return "That username was just taken. Please choose another.";
  if (msg.includes("password"))
    return "Password is too weak. Use at least 8 characters with letters and numbers.";
  if (msg.includes("rate limit") || msg.includes("too many requests"))
    return "Too many attempts. Please wait a moment and try again.";
  if (msg.includes("failed to fetch") || msg.includes("networkerror"))
    return "Network error — check your connection and try again.";
  return error?.message || "Something went wrong. Please try again.";
}
