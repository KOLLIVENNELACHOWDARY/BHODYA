// Pure validation helpers for the auth feature (Login / Signup).
// No React/JSX imports here on purpose — these are unit-testable with plain
// node. The single age -> age-band rule lives in context/AgeContext.jsx
// (getAgeBand) per ARCHITECTURE.md; Signup.jsx passes the computed band into
// buildProfilePayload so there is exactly one age-classification system.

export const USERNAME_REGEX = /^[a-z][a-z0-9_]{2,19}$/;

export function normalizeUsername(value) {
  return String(value ?? "")
    .trim()
    .toLowerCase();
}

/** Returns "" when valid, otherwise a human-readable error. */
export function validateEmail(email) {
  const value = String(email ?? "").trim();
  if (!value) return "Email is required.";
  // Pragmatic email shape check — no external validation service needed.
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
  return ok ? "" : "Enter a valid email address.";
}

/** Returns "" when valid, otherwise a human-readable error. */
export function validateUsername(username) {
  const value = normalizeUsername(username);
  if (!value) return "Username is required.";
  if (value.length < 3 || value.length > 20)
    return "Username must be 3–20 characters.";
  if (!USERNAME_REGEX.test(value))
    return "Use lowercase letters, numbers and underscores only. Must start with a letter.";
  return "";
}

/**
 * Password rules: 8+ chars, at least one uppercase, one lowercase, one digit.
 * Returns { error, strength } where strength is 0..4 (0 = empty).
 */
export function validatePassword(password) {
  const value = String(password ?? "");
  if (!value) return { error: "Password is required.", strength: 0 };

  let strength = 0;
  if (value.length >= 8) strength += 1;
  if (/[a-z]/.test(value)) strength += 1;
  if (/[A-Z]/.test(value)) strength += 1;
  if (/[0-9]/.test(value)) strength += 1;
  if (/[^A-Za-z0-9]/.test(value) && value.length >= 10) strength = Math.min(4, strength + 1);

  const missing = [];
  if (value.length < 8) missing.push("at least 8 characters");
  if (!/[a-z]/.test(value)) missing.push("a lowercase letter");
  if (!/[A-Z]/.test(value)) missing.push("an uppercase letter");
  if (!/[0-9]/.test(value)) missing.push("a number");

  return {
    error: missing.length
      ? `Password needs ${missing.join(", ")}.`
      : "",
    strength,
  };
}

export function validateConfirmPassword(password, confirm) {
  if (!confirm) return "Please confirm your password.";
  return password === confirm ? "" : "Passwords do not match.";
}

/** Returns "" when valid, otherwise a human-readable error. */
export function validateAge(age) {
  const raw = String(age ?? "").trim();
  if (!raw) return "Age is required.";
  if (!/^\d+$/.test(raw)) return "Age must be a whole number.";
  const n = Number(raw);
  if (n < 5 || n > 100) return "Age must be between 5 and 100.";
  return "";
}

/** Education step (Step 2). Returns a map of field -> error. */
export function validateEducation(edu) {
  const errors = {};
  const level = edu.education_level;
  if (!level) {
    errors.education_level = "Select your education level.";
    return errors;
  }
  if (level === "high_school") {
    if (!String(edu.class_grade ?? "").trim())
      errors.class_grade = "Enter your class/grade.";
    if (!edu.subjects?.length)
      errors.subjects = "Select at least one subject.";
  } else if (level === "undergraduate" || level === "postgraduate") {
    if (!String(edu.course ?? "").trim())
      errors.course = "Enter your degree/course.";
    if (level === "undergraduate" && !String(edu.branch ?? "").trim())
      errors.branch = "Enter your branch/department.";
    if (level === "postgraduate" && !String(edu.specialization ?? "").trim())
      errors.specialization = "Enter your specialization.";
    if (!String(edu.current_year ?? "").trim())
      errors.current_year = "Select your current year.";
  } else if (level === "other") {
    if (!String(edu.course ?? "").trim())
      errors.course = "Briefly describe your education.";
  }
  return errors;
}

/** Learning preferences step (Step 3). Returns a map of field -> error. */
export function validatePreferences(prefs) {
  const errors = {};
  if (!prefs.content_preferences?.length)
    errors.content_preferences = "Pick at least one content style.";
  if (!prefs.interest_subjects?.length)
    errors.interest_subjects = "Pick at least one subject you want to learn.";
  if (!prefs.learning_goals?.length)
    errors.learning_goals = "Pick at least one learning goal.";
  if (!prefs.preferred_difficulty)
    errors.preferred_difficulty = "Select your preferred difficulty.";
  if (!prefs.preferred_language)
    errors.preferred_language = "Select your preferred language.";
  return errors;
}

/**
 * Build the profile payload sent to Supabase Auth as user_metadata.
 * The handle_new_user() DB trigger copies it into the profiles table.
 * `ageBand` must come from getAgeBand() in context/AgeContext.jsx — the one
 * and only age-classification system in the app.
 * NEVER put the password here — Supabase Auth owns it.
 */
export function buildProfilePayload({ basic, education, preferences, ageBand }) {
  return {
    username: normalizeUsername(basic.username),
    age: Number(basic.age),
    age_band: ageBand, // 'child' | 'teen' | 'adult'
    education_level: education.education_level,
    class_grade: String(education.class_grade ?? "").trim() || null,
    course: String(education.course ?? "").trim() || null,
    branch: String(education.branch ?? "").trim() || null,
    specialization: String(education.specialization ?? "").trim() || null,
    current_year: String(education.current_year ?? "").trim() || null,
    subjects: education.subjects ?? [],
    content_preferences: preferences.content_preferences ?? [],
    interest_subjects: preferences.interest_subjects ?? [],
    learning_goals: preferences.learning_goals ?? [],
    preferred_difficulty: preferences.preferred_difficulty,
    preferred_language: preferences.preferred_language,
    onboarding_completed: true,
  };
}
