import { useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { getAgeBand } from "../../context/AgeContext.jsx";
import { checkUsernameAvailable, signUp } from "./api";
import {
  validateEmail,
  validateUsername,
  validatePassword,
  validateConfirmPassword,
  validateAge,
  validateEducation,
  validatePreferences,
  normalizeUsername,
} from "./validation";
import { AuthShell, FieldError, Label, Spinner, inputClass } from "./ui.jsx";

const chipBase =
  "rounded-full border px-3.5 py-1.5 text-sm transition select-none cursor-pointer ";
const chipOn = "border-indigo-500 bg-indigo-50 text-indigo-700 font-medium";
const chipOff = "border-slate-200 bg-white text-slate-600 hover:border-indigo-300";

const EDUCATION_LEVELS = [
  ["", "Select your education level"],
  ["high_school", "High School"],
  ["undergraduate", "Undergraduate (UG)"],
  ["postgraduate", "Postgraduate (PG)"],
  ["other", "Other"],
];

const CLASS_GRADES = ["Class 5", "Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12"];
const UG_YEARS = ["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year"];
const PG_YEARS = ["1st Year", "2nd Year", "3rd Year"];

const SUBJECT_OPTIONS = [
  "Maths", "Physics", "Chemistry", "Biology", "English", "Social Studies",
  "History", "Geography", "Civics", "Economics", "Computer Science",
  "Commerce / Accountancy", "Telugu", "Hindi",
];

const CONTENT_PREFERENCES = [
  ["step_by_step", "Step-by-step explanations"],
  ["visual", "Visual explanations"],
  ["examples", "Examples"],
  ["practice", "Practice questions"],
  ["short_summaries", "Short summaries"],
  ["detailed", "Detailed explanations"],
];

const LEARNING_GOALS = [
  ["exam_prep", "Exam preparation"],
  ["concepts", "Understanding concepts"],
  ["homework", "Homework / Assignments"],
  ["competitive", "Competitive exams"],
  ["skills", "Skill development"],
  ["interview", "Interview preparation"],
  ["general", "General learning"],
];

const DIFFICULTIES = [
  ["beginner", "Beginner"],
  ["intermediate", "Intermediate"],
  ["advanced", "Advanced"],
];

const LANGUAGES = [
  ["english", "English"],
  ["telugu", "Telugu"],
  ["hindi", "Hindi"],
  ["other", "Other"],
];

const STEP_TITLES = ["Basic details", "Education", "Learning preferences"];

function ChipMulti({ options, value, onChange, error }) {
  function toggle(v) {
    onChange(value.includes(v) ? value.filter((x) => x !== v) : [...value, v]);
  }
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {options.map(([val, label]) => (
          <button
            key={val}
            type="button"
            aria-pressed={value.includes(val)}
            onClick={() => toggle(val)}
            className={chipBase + (value.includes(val) ? chipOn : chipOff)}
          >
            {label}
          </button>
        ))}
      </div>
      <FieldError message={error} />
    </div>
  );
}

function ChoiceRow({ options, value, onChange, error }) {
  return (
    <div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {options.map(([val, label]) => (
          <button
            key={val}
            type="button"
            aria-pressed={value === val}
            onClick={() => onChange(val)}
            className={`rounded-xl border px-3 py-2.5 text-sm transition ${
              value === val
                ? "border-indigo-500 bg-indigo-50 text-indigo-700 font-medium"
                : "border-slate-200 bg-white text-slate-600 hover:border-indigo-300"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
      <FieldError message={error} />
    </div>
  );
}

export default function SignupPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  const [step, setStep] = useState(0); // 0 basic | 1 education | 2 preferences
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [errors, setErrors] = useState({});
  const [done, setDone] = useState(false); // needs-email-confirmation success screen
  const [showPw, setShowPw] = useState(false);

  const [basic, setBasic] = useState({
    email: "", username: "", password: "", confirm: "", age: "",
  });
  const [education, setEducation] = useState({
    education_level: "", class_grade: "", course: "", branch: "",
    specialization: "", current_year: "", subjects: [],
  });
  const [preferences, setPreferences] = useState({
    content_preferences: [], interest_subjects: [], learning_goals: [],
    preferred_difficulty: "", preferred_language: "",
  });

  const [usernameStatus, setUsernameStatus] = useState(""); // "" | "checking" | "available" | "taken"

  useEffect(() => {
    if (!loading && user) navigate("/", { replace: true });
  }, [loading, user, navigate]);

  if (loading) {
    return (
      <AuthShell title="Create your account" subtitle="Checking your session…">
        <div className="flex justify-center py-8">
          <Spinner className="border-indigo-200 border-t-indigo-600 h-6 w-6" />
        </div>
      </AuthShell>
    );
  }
  if (user) return <Navigate to="/" replace />;

  if (done) {
    return (
      <AuthShell title="Check your email ✉️" subtitle="One last step before you can log in">
        <p className="text-sm text-slate-600">
          We created your account for <span className="font-semibold">{basic.email}</span>.
          Open the confirmation link in your inbox, then log in with your email or
          username <span className="font-semibold">{basic.username}</span>.
        </p>
        <Link
          to="/login"
          className="mt-5 flex w-full items-center justify-center rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-200 transition hover:bg-indigo-700"
        >
          Go to login
        </Link>
      </AuthShell>
    );
  }

  const setB = (k) => (e) => setBasic((s) => ({ ...s, [k]: e.target.value }));
  const setE = (k) => (e) => setEducation((s) => ({ ...s, [k]: e.target.value }));
  const setP = (k) => (v) => setPreferences((s) => ({ ...s, [k]: v }));

  // Username availability check (Supabase only — reads the public usernames
  // table). Final uniqueness is enforced by the database on signup.
  async function checkUsername() {
    const value = normalizeUsername(basic.username);
    if (validateUsername(value)) {
      setUsernameStatus("");
      return;
    }
    setUsernameStatus("checking");
    const { available } = await checkUsernameAvailable(value);
    setUsernameStatus(available ? "available" : "taken");
  }

  const passwordCheck = validatePassword(basic.password);

  function validateStep0() {
    const errs = {};
    const emailErr = validateEmail(basic.email);
    if (emailErr) errs.email = emailErr;
    const userErr = validateUsername(basic.username);
    if (userErr) errs.username = userErr;
    else if (usernameStatus === "taken") errs.username = "That username is already taken.";
    if (passwordCheck.error) errs.password = passwordCheck.error;
    const confirmErr = validateConfirmPassword(basic.password, basic.confirm);
    if (confirmErr) errs.confirm = confirmErr;
    const ageErr = validateAge(basic.age);
    if (ageErr) errs.age = ageErr;
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleNext(e) {
    e.preventDefault();
    setFormError("");
    if (step === 0) {
      if (!validateStep0()) return;
      // Re-check availability right before advancing (cheap, avoids stale UI).
      const { available } = await checkUsernameAvailable(basic.username);
      if (!available) {
        setErrors({ username: "That username is already taken." });
        setUsernameStatus("taken");
        return;
      }
      setStep(1);
    } else if (step === 1) {
      const errs = validateEducation(education);
      setErrors(errs);
      if (Object.keys(errs).length === 0) setStep(2);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setFormError("");
    const errs = validatePreferences(preferences);
    setErrors(errs);
    if (Object.keys(errs).length) return;

    setSubmitting(true);
    try {
      const result = await signUp({
        email: basic.email,
        password: basic.password,
        basic,
        education,
        preferences,
      });
      if (!result.ok) {
        setFormError(result.error);
        // If the failure was a username race, send the user back to step 1.
        if (result.error.toLowerCase().includes("username")) setStep(0);
        return;
      }
      if (result.needsEmailConfirmation) {
        setDone(true); // email confirmation required by the Supabase project
      } else {
        navigate("/", { replace: true }); // session active via AuthContext
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthShell title="Create your account" subtitle="Three quick steps and BODHYA is ready for you">
      {/* Step indicator */}
      <ol className="mb-6 flex items-center gap-2">
        {STEP_TITLES.map((title, i) => (
          <li key={title} className="flex flex-1 items-center gap-2">
            <span
              className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                i < step
                  ? "bg-emerald-500 text-white"
                  : i === step
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-100 text-slate-400"
              }`}
            >
              {i < step ? "✓" : i + 1}
            </span>
            <span
              className={`hidden text-xs font-medium sm:block ${
                i === step ? "text-indigo-700" : "text-slate-400"
              }`}
            >
              {title}
            </span>
            {i < STEP_TITLES.length - 1 && <span className="h-px flex-1 bg-slate-200" />}
          </li>
        ))}
      </ol>

      <form onSubmit={step === 2 ? handleSubmit : handleNext} noValidate className="space-y-4">
        {step === 0 && (
          <>
            <div>
              <Label htmlFor="email">Email address</Label>
              <input
                id="email" type="email" autoComplete="email" placeholder="you@example.com"
                value={basic.email} onChange={setB("email")} className={inputClass} disabled={submitting}
              />
              <FieldError message={errors.email} />
            </div>

            <div>
              <Label htmlFor="username">Username</Label>
              <input
                id="username" type="text" autoComplete="username" placeholder="e.g. priya_2007"
                value={basic.username}
                onChange={(e) => {
                  setBasic((s) => ({ ...s, username: e.target.value }));
                  setUsernameStatus("");
                }}
                onBlur={checkUsername}
                className={inputClass}
                disabled={submitting}
              />
              {usernameStatus === "checking" && (
                <p className="mt-1 text-xs text-slate-500">Checking availability…</p>
              )}
              {usernameStatus === "available" && !errors.username && (
                <p className="mt-1 text-xs text-emerald-600">Username is available ✓</p>
              )}
              {usernameStatus === "taken" && !errors.username && (
                <p className="mt-1 text-xs text-rose-600">That username is already taken.</p>
              )}
              <FieldError message={errors.username} />
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <input
                  id="password" type={showPw ? "text" : "password"} autoComplete="new-password"
                  placeholder="At least 8 characters"
                  value={basic.password} onChange={setB("password")}
                  className={`${inputClass} pr-16`} disabled={submitting}
                />
                <button
                  type="button" onClick={() => setShowPw((s) => !s)}
                  className="absolute inset-y-0 right-0 px-3 text-xs font-medium text-indigo-600 hover:text-indigo-800"
                  aria-label={showPw ? "Hide password" : "Show password"}
                >
                  {showPw ? "Hide" : "Show"}
                </button>
              </div>
              {/* Strength meter */}
              {basic.password && (
                <div className="mt-2 flex items-center gap-2">
                  <div className="flex flex-1 gap-1">
                    {[1, 2, 3, 4].map((lvl) => (
                      <span
                        key={lvl}
                        className={`h-1.5 flex-1 rounded-full ${
                          passwordCheck.strength >= lvl
                            ? passwordCheck.strength <= 2
                              ? "bg-amber-400"
                              : "bg-emerald-500"
                            : "bg-slate-200"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-slate-500">
                    {passwordCheck.strength <= 2 ? "Weak" : passwordCheck.strength === 3 ? "Good" : "Strong"}
                  </span>
                </div>
              )}
              <FieldError message={errors.password} />
            </div>

            <div>
              <Label htmlFor="confirm">Confirm password</Label>
              <input
                id="confirm" type={showPw ? "text" : "password"} autoComplete="new-password"
                placeholder="Repeat your password"
                value={basic.confirm} onChange={setB("confirm")} className={inputClass} disabled={submitting}
              />
              <FieldError message={errors.confirm} />
            </div>

            <div>
              <Label htmlFor="age">Age</Label>
              <input
                id="age" type="number" min="5" max="100" inputMode="numeric" placeholder="e.g. 15"
                value={basic.age} onChange={setB("age")} className={inputClass} disabled={submitting}
              />
              {validateAge(basic.age) === "" && (
                <p className="mt-1 text-xs text-slate-500">
                  Learning mode:{" "}
                  <span className="font-medium text-indigo-600 capitalize">
                    {getAgeBand(Number(basic.age))}
                  </span>{" "}
                  (adjusts how BODHYA explains things)
                </p>
              )}
              <FieldError message={errors.age} />
            </div>
          </>
        )}

        {step === 1 && (
          <>
            <div>
              <Label htmlFor="education_level">Education level</Label>
              <select
                id="education_level" value={education.education_level}
                onChange={setE("education_level")} className={inputClass} disabled={submitting}
              >
                {EDUCATION_LEVELS.map(([val, label]) => (
                  <option key={val} value={val}>{label}</option>
                ))}
              </select>
              <FieldError message={errors.education_level} />
            </div>

            {education.education_level === "high_school" && (
              <>
                <div>
                  <Label htmlFor="class_grade">Class / Grade</Label>
                  <select
                    id="class_grade" value={education.class_grade}
                    onChange={setE("class_grade")} className={inputClass} disabled={submitting}
                  >
                    <option value="">Select your class</option>
                    {CLASS_GRADES.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                  <FieldError message={errors.class_grade} />
                </div>
                <div>
                  <Label>Subjects you study</Label>
                  <ChipMulti
                    options={SUBJECT_OPTIONS.map((s) => [s, s])}
                    value={education.subjects}
                    onChange={(v) => setEducation((s) => ({ ...s, subjects: v }))}
                    error={errors.subjects}
                  />
                </div>
              </>
            )}

            {(education.education_level === "undergraduate" ||
              education.education_level === "postgraduate") && (
              <>
                <div>
                  <Label htmlFor="course">Degree / Course</Label>
                  <input
                    id="course" type="text" placeholder="e.g. B.Tech, B.Sc, M.Com"
                    value={education.course} onChange={setE("course")} className={inputClass} disabled={submitting}
                  />
                  <FieldError message={errors.course} />
                </div>
                {education.education_level === "undergraduate" && (
                  <div>
                    <Label htmlFor="branch">Branch / Department</Label>
                    <input
                      id="branch" type="text" placeholder="e.g. Computer Science"
                      value={education.branch} onChange={setE("branch")} className={inputClass} disabled={submitting}
                    />
                    <FieldError message={errors.branch} />
                  </div>
                )}
                {education.education_level === "postgraduate" && (
                  <div>
                    <Label htmlFor="specialization">Specialization</Label>
                    <input
                      id="specialization" type="text" placeholder="e.g. Data Science"
                      value={education.specialization} onChange={setE("specialization")}
                      className={inputClass} disabled={submitting}
                    />
                    <FieldError message={errors.specialization} />
                  </div>
                )}
                <div>
                  <Label htmlFor="current_year">Current year</Label>
                  <select
                    id="current_year" value={education.current_year}
                    onChange={setE("current_year")} className={inputClass} disabled={submitting}
                  >
                    <option value="">Select your year</option>
                    {(education.education_level === "undergraduate" ? UG_YEARS : PG_YEARS).map((y) => (
                      <option key={y} value={y}>{y}</option>
                    ))}
                  </select>
                  <FieldError message={errors.current_year} />
                </div>
              </>
            )}

            {education.education_level === "other" && (
              <div>
                <Label htmlFor="course_other">Tell us about your education</Label>
                <input
                  id="course_other" type="text"
                  placeholder="e.g. Diploma in Mechanical Engineering, coaching for CA…"
                  value={education.course} onChange={setE("course")} className={inputClass} disabled={submitting}
                />
                <FieldError message={errors.course} />
              </div>
            )}
          </>
        )}

        {step === 2 && (
          <>
            <div>
              <Label>How do you like to learn? (pick any)</Label>
              <ChipMulti
                options={CONTENT_PREFERENCES}
                value={preferences.content_preferences}
                onChange={setP("content_preferences")}
                error={errors.content_preferences}
              />
            </div>
            <div>
              <Label>Subjects you want to learn (pick any)</Label>
              <ChipMulti
                options={SUBJECT_OPTIONS.map((s) => [s, s])}
                value={preferences.interest_subjects}
                onChange={setP("interest_subjects")}
                error={errors.interest_subjects}
              />
            </div>
            <div>
              <Label>Learning goals (pick any)</Label>
              <ChipMulti
                options={LEARNING_GOALS}
                value={preferences.learning_goals}
                onChange={setP("learning_goals")}
                error={errors.learning_goals}
              />
            </div>
            <div>
              <Label>Preferred difficulty</Label>
              <ChoiceRow
                options={DIFFICULTIES}
                value={preferences.preferred_difficulty}
                onChange={setP("preferred_difficulty")}
                error={errors.preferred_difficulty}
              />
            </div>
            <div>
              <Label>Preferred language</Label>
              <ChoiceRow
                options={LANGUAGES}
                value={preferences.preferred_language}
                onChange={setP("preferred_language")}
                error={errors.preferred_language}
              />
            </div>
          </>
        )}

        {formError && (
          <div className="rounded-xl bg-rose-50 px-4 py-3 text-sm text-rose-700 ring-1 ring-rose-100">
            {formError}
          </div>
        )}

        <div className="flex gap-3 pt-2">
          {step > 0 && (
            <button
              type="button"
              onClick={() => { setStep((s) => s - 1); setErrors({}); setFormError(""); }}
              className="rounded-xl border border-slate-200 px-5 py-2.5 text-sm font-semibold text-slate-600 transition hover:bg-slate-50"
              disabled={submitting}
            >
              Back
            </button>
          )}
          <button
            type="submit"
            disabled={submitting}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-200 transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-70"
          >
            {submitting && <Spinner />}
            {submitting
              ? "Creating account…"
              : step === 2
              ? "Create my account"
              : "Next"}
          </button>
        </div>
      </form>

      <p className="mt-6 text-center text-sm text-slate-500">
        Already have an account?{" "}
        <Link to="/login" className="font-semibold text-indigo-600 hover:text-indigo-800">
          Log in
        </Link>
      </p>
    </AuthShell>
  );
}
