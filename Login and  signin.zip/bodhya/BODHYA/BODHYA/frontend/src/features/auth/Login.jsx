import { useEffect, useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { loginWithEmail, loginWithUsername } from "./api";
import { validateEmail, validateUsername } from "./validation";
import { AuthShell, FieldError, Label, Spinner, inputClass } from "./ui.jsx";

export default function LoginPage() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  const [mode, setMode] = useState("email"); // "email" | "username"
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Already signed in? No reason to stay on /login.
  useEffect(() => {
    if (!loading && user) navigate("/", { replace: true });
  }, [loading, user, navigate]);

  if (loading) {
    return (
      <AuthShell title="Welcome back" subtitle="Checking your session…">
        <div className="flex justify-center py-8">
          <Spinner className="border-indigo-200 border-t-indigo-600 h-6 w-6" />
        </div>
      </AuthShell>
    );
  }
  if (user) return <Navigate to="/" replace />;

  function switchMode(next) {
    setMode(next);
    setIdentifier("");
    setFieldErrors({});
    setFormError("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setFormError("");

    // Inline validation first (all local — no external validation API).
    const errors = {};
    if (mode === "email") {
      const err = validateEmail(identifier);
      if (err) errors.identifier = err;
    } else {
      const err = validateUsername(identifier);
      if (err) errors.identifier = err;
    }
    if (!password) errors.password = "Password is required.";
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;

    setSubmitting(true);
    try {
      const result =
        mode === "email"
          ? await loginWithEmail(identifier, password)
          : await loginWithUsername(identifier, password);
      if (result.ok) {
        // AuthContext's onAuthStateChange picks up the session.
        navigate("/", { replace: true });
      } else {
        setFormError(result.error);
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <AuthShell title="Welcome back" subtitle="Log in to continue learning with BODHYA">
      {/* Email | Username selector */}
      <div
        className="mb-5 grid grid-cols-2 gap-1 rounded-xl bg-slate-100 p-1"
        role="tablist"
        aria-label="Login method"
      >
        {[
          ["email", "Email"],
          ["username", "Username"],
        ].map(([value, label]) => (
          <button
            key={value}
            type="button"
            role="tab"
            aria-selected={mode === value}
            onClick={() => switchMode(value)}
            className={`rounded-lg py-2 text-sm font-medium transition ${
              mode === value
                ? "bg-white text-indigo-700 shadow-sm"
                : "text-slate-500 hover:text-slate-700"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        <div>
          <Label htmlFor="identifier">
            {mode === "email" ? "Email address" : "Username"}
          </Label>
          <input
            id="identifier"
            type={mode === "email" ? "email" : "text"}
            autoComplete={mode === "email" ? "email" : "username"}
            placeholder={mode === "email" ? "you@example.com" : "your_username"}
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            className={inputClass}
            disabled={submitting}
          />
          <FieldError message={fieldErrors.identifier} />
        </div>

        <div>
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`${inputClass} pr-16`}
              disabled={submitting}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className="absolute inset-y-0 right-0 px-3 text-xs font-medium text-indigo-600 hover:text-indigo-800"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
          <FieldError message={fieldErrors.password} />
        </div>

        {formError && (
          <div className="rounded-xl bg-rose-50 px-4 py-3 text-sm text-rose-700 ring-1 ring-rose-100">
            {formError}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white shadow-lg shadow-indigo-200 transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-70"
        >
          {submitting && <Spinner />}
          {submitting ? "Logging in…" : "Log in"}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-slate-500">
        New to BODHYA?{" "}
        <Link to="/signup" className="font-semibold text-indigo-600 hover:text-indigo-800">
          Create an account
        </Link>
      </p>
    </AuthShell>
  );
}
