import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LoginPage, SignupPage } from "./features/auth";

// Each feature owns one page — import your page component here and add
// a route. Keep this file small; build the actual feature inside
// src/features/<your-feature>/.

function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-2xl font-semibold">AI Learning Companion</h1>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        {/* <Route path="/dashboard" element={<Dashboard />} /> */}
        {/* <Route path="/chat" element={<TutorChat />} /> */}
        {/* add your feature's route here */}
      </Routes>
    </BrowserRouter>
  );
}
