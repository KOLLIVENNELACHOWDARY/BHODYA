# Age-Adaptive Dashboard

Put your components, hooks, and API-call file for this feature here.

**Suggested files:**
- `index.jsx` — main component, exported for use in a route in App.jsx
- `api.js` — calls to Supabase directly and/or Supabase reads (profiles, streaks, knowledge_nodes)
- any sub-components you need

**Backend:** Supabase reads (profiles, streaks, knowledge_nodes)

Don't edit files outside this folder (except adding one route line in
`App.jsx` and, if needed, extending your matching backend router).
